import { useState, useCallback } from "react";
import * as XLSX from "xlsx";
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

const C = {
  bg:"#080d14", surface:"#0e1520", card:"#111b2b", border:"#1e3048",
  accent:"#00d4aa", gold:"#f0b429", green:"#22c55e", red:"#f43f5e",
  blue:"#3b82f6", purple:"#a855f7", cyan:"#06b6d4", orange:"#fb923c",
  text:"#e2eaf6", muted:"#5b7494", dim:"#2a3f58",
};

const SYSTEM_VERSION = "2.0.0";
const SYSTEM_NAME    = "Makin BizSystem";
const OWNER_MOMO     = { name:"Makin Limited", number:"0596363851", network:"MTN MoMo" };

const PLANS = [
  { id:"basic",      name:"Basic",      price:50,  color:C.blue,   features:["Inventory Management","Sales & Invoicing","Customer Management","Export/Import Backup","Up to 2 staff"] },
  { id:"pro",        name:"Pro",        price:120, color:C.accent, badge:"Most Popular", features:["Everything in Basic","Purchase Orders","Supplier Management","Expense Tracking","Reports & Analytics","Delivery Tracking","Up to 10 staff"] },
  { id:"enterprise", name:"Enterprise", price:250, color:C.purple, features:["Everything in Pro","Unlimited staff","Price List Manager","Debt Tracker","Notifications","Priority support"] },
];

/* ── OWNER CREDENTIALS (system owner always bypasses subscription) ── */
const OWNER = {
  email:    "admin@makinlimited.com",
  password: "Makin@2024",
  bizName:  "Makin Limited",
  role:     "owner",
  plan:     "enterprise",
};

/* ── ROLES ── */
const ROLES = [
  { id:"owner",   label:"Owner",   color:C.purple, desc:"Full access to everything including admin panel" },
  { id:"admin",   label:"Admin",   color:C.accent, desc:"Full access except owner settings" },
  { id:"manager", label:"Manager", color:C.blue,   desc:"Can view all, edit inventory/sales/purchases" },
  { id:"cashier", label:"Cashier", color:C.green,  desc:"Sales and invoicing only" },
  { id:"viewer",  label:"Viewer",  color:C.muted,  desc:"Read-only access to all pages" },
];

/* Initial registered users store */
const INITIAL_USERS = [
  { id:1, email:OWNER.email, password:OWNER.password, bizName:OWNER.bizName, phone:"0596363851", role:"owner",   plan:"enterprise", activatedAt:new Date(Date.now()-90*86400000).toISOString(), expiresAt:new Date(Date.now()+275*86400000).toISOString(), isOwner:true  },
];

/* MTN MoMo Transaction ID format: typically 10-12 digit numeric string */
function isValidMoMoRef(ref){
  // Must be 10-13 digits only (real MTN MoMo transaction IDs)
  return /^[0-9]{10,13}$/.test(ref.trim());
}

const initialData = {
  inventory:[
    {id:1,name:"Rice (50kg)",category:"Grains",qty:120,unit:"bags",cost:45,price:58,reorder:20},
    {id:2,name:"Palm Oil (25L)",category:"Oils",qty:12,unit:"cans",cost:32,price:42,reorder:15},
    {id:3,name:"Sugar (50kg)",category:"Sweeteners",qty:60,unit:"bags",cost:38,price:50,reorder:10},
    {id:4,name:"Flour (50kg)",category:"Grains",qty:45,unit:"bags",cost:30,price:40,reorder:10},
    {id:5,name:"Salt (25kg)",category:"Condiments",qty:200,unit:"bags",cost:8,price:12,reorder:30},
    {id:6,name:"Tomato Paste (carton)",category:"Condiments",qty:8,unit:"cartons",cost:22,price:30,reorder:10},
  ],
  customers:[
    {id:1,name:"Bright Stores",contact:"Bright Mensah",phone:"0244123456",email:"bright@stores.com",address:"Accra Central",balance:450,totalBought:1200},
    {id:2,name:"Kwame Supermarket",contact:"Kwame Asante",phone:"0201987654",email:"kwame@super.com",address:"Tema",balance:0,totalBought:850},
    {id:3,name:"Grace Provisions",contact:"Grace Owusu",phone:"0551234567",email:"grace@provisions.com",address:"Kumasi",balance:200,totalBought:620},
  ],
  suppliers:[
    {id:1,name:"Accra Mills Ltd",contact:"Mr. Darko",phone:"0302112233",email:"sales@accramills.com",product:"Grains & Flour",balance:0},
    {id:2,name:"West Africa Oils",contact:"Mrs. Tetteh",phone:"0244556677",email:"orders@waoils.com",product:"Palm Oil",balance:1200},
    {id:3,name:"Sahara Trading",contact:"Alhaji Musa",phone:"0201334455",email:"sahara@trade.com",product:"Condiments",balance:0},
  ],
  sales:[
    {id:1001,date:"2025-09-10",customer:"Bright Stores",items:[{name:"Rice (50kg)",qty:5,price:58},{name:"Sugar (50kg)",qty:3,price:50}],total:440,status:"paid"},
    {id:1002,date:"2025-10-12",customer:"Kwame Supermarket",items:[{name:"Palm Oil (25L)",qty:10,price:42}],total:420,status:"paid"},
    {id:1003,date:"2025-11-15",customer:"Grace Provisions",items:[{name:"Flour (50kg)",qty:4,price:40}],total:160,status:"unpaid"},
    {id:1004,date:"2025-12-03",customer:"Bright Stores",items:[{name:"Salt (25kg)",qty:20,price:12}],total:240,status:"paid"},
    {id:1005,date:"2026-01-08",customer:"Kwame Supermarket",items:[{name:"Rice (50kg)",qty:8,price:58}],total:464,status:"paid"},
    {id:1006,date:"2026-02-20",customer:"Grace Provisions",items:[{name:"Tomato Paste (carton)",qty:5,price:30}],total:150,status:"unpaid"},
    {id:1007,date:"2026-03-01",customer:"Bright Stores",items:[{name:"Sugar (50kg)",qty:6,price:50}],total:300,status:"paid"},
  ],
  purchases:[
    {id:2001,date:"2025-09-05",supplier:"Accra Mills Ltd",items:[{name:"Rice (50kg)",qty:50,cost:45}],total:2250,status:"paid"},
    {id:2002,date:"2025-10-08",supplier:"West Africa Oils",items:[{name:"Palm Oil (25L)",qty:40,cost:32}],total:1280,status:"unpaid"},
    {id:2003,date:"2025-11-14",supplier:"Sahara Trading",items:[{name:"Salt (25kg)",qty:100,cost:8}],total:800,status:"paid"},
    {id:2004,date:"2025-12-10",supplier:"Accra Mills Ltd",items:[{name:"Flour (50kg)",qty:30,cost:30}],total:900,status:"paid"},
    {id:2005,date:"2026-01-06",supplier:"West Africa Oils",items:[{name:"Palm Oil (25L)",qty:20,cost:32}],total:640,status:"paid"},
    {id:2006,date:"2026-02-18",supplier:"Sahara Trading",items:[{name:"Tomato Paste (carton)",qty:20,cost:22}],total:440,status:"unpaid"},
  ],
  expenses:[
    {id:1,date:"2026-01-02",category:"Rent",description:"Monthly warehouse rent",amount:800},
    {id:2,date:"2026-01-05",category:"Transport",description:"Delivery truck fuel",amount:120},
    {id:3,date:"2026-02-10",category:"Utilities",description:"Electricity bill",amount:95},
    {id:4,date:"2026-02-15",category:"Salaries",description:"Staff wages Feb",amount:1500},
    {id:5,date:"2026-03-01",category:"Rent",description:"Monthly warehouse rent",amount:800},
  ],
  staff:[
    {id:1,name:"Ama Boateng",role:"Manager",email:"ama@makin.com",phone:"0244001122",status:"active",salary:1200},
    {id:2,name:"Kofi Agyeman",role:"Sales Rep",email:"kofi@makin.com",phone:"0201556677",status:"active",salary:800},
    {id:3,name:"Abena Frimpong",role:"Accountant",email:"abena@makin.com",phone:"0551889900",status:"active",salary:950},
  ],
  deliveries:[
    {id:3001,date:"2026-02-20",customer:"Bright Stores",invoice:1007,driver:"Kofi Agyeman",status:"delivered",address:"Accra Central"},
    {id:3002,date:"2026-03-01",customer:"Grace Provisions",invoice:1006,driver:"Kofi Agyeman",status:"pending",address:"Kumasi"},
  ],
  notifications:[
    {id:1,type:"alert",message:"Palm Oil (25L) is below reorder level",time:"2 hrs ago",read:false},
    {id:2,type:"payment",message:"Invoice #1007 paid by Bright Stores",time:"Today",read:false},
    {id:3,type:"info",message:"New purchase order #2006 recorded",time:"Yesterday",read:true},
  ],
};

/* ── SHARED UI ── */
function Modal({title,onClose,children,wide}){
  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.82)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:20}}>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:18,padding:32,width:"100%",maxWidth:wide?720:540,maxHeight:"90vh",overflowY:"auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
          <h3 style={{color:C.accent,fontFamily:"'Playfair Display',serif",fontSize:20,margin:0}}>{title}</h3>
          <button onClick={onClose} style={{background:"none",border:"none",color:C.muted,fontSize:22,cursor:"pointer"}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
function FIn({label,value,onChange,type="text",placeholder=""}){
  return(
    <div style={{marginBottom:13}}>
      {label&&<label style={{display:"block",color:C.muted,fontSize:11,marginBottom:5,textTransform:"uppercase",letterSpacing:1}}>{label}</label>}
      <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        style={{width:"100%",background:C.surface,border:`1px solid ${C.border}`,borderRadius:8,padding:"9px 13px",color:C.text,fontSize:13,outline:"none",boxSizing:"border-box"}}/>
    </div>
  );
}
function FSel({label,value,onChange,options}){
  return(
    <div style={{marginBottom:13}}>
      {label&&<label style={{display:"block",color:C.muted,fontSize:11,marginBottom:5,textTransform:"uppercase",letterSpacing:1}}>{label}</label>}
      <select value={value} onChange={e=>onChange(e.target.value)}
        style={{width:"100%",background:C.surface,border:`1px solid ${C.border}`,borderRadius:8,padding:"9px 13px",color:C.text,fontSize:13,outline:"none",boxSizing:"border-box"}}>
        {options.map(o=><option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}
function Btn({children,onClick,color=C.accent,small,outline,full}){
  return(
    <button onClick={onClick} style={{
      background:outline?"transparent":color,color:outline?color:"#080d14",
      border:`1.5px solid ${color}`,borderRadius:8,
      padding:small?"5px 12px":"10px 20px",
      fontWeight:700,fontSize:small?11:13,cursor:"pointer",
      fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:1,
      width:full?"100%":"auto"
    }}>{children}</button>
  );
}
function Badge({label,color}){
  return <span style={{background:color+"22",color,border:`1px solid ${color}44`,borderRadius:6,padding:"2px 9px",fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:0.8,whiteSpace:"nowrap"}}>{label}</span>;
}
function KCard({label,value,sub,color=C.accent,icon,trend}){
  return(
    <div style={{background:`linear-gradient(135deg,${C.card} 60%,${color}0a)`,border:`1px solid ${color}33`,borderRadius:14,padding:"20px 22px",flex:1,minWidth:150,position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",top:12,right:14,fontSize:24,opacity:0.1,color}}>{icon}</div>
      <div style={{color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1.5,marginBottom:7}}>{label}</div>
      <div style={{color,fontSize:24,fontWeight:800,fontFamily:"'Playfair Display',serif",marginBottom:3}}>{value}</div>
      {sub&&<div style={{color:C.muted,fontSize:11}}>{sub}</div>}
      {trend!=null&&<div style={{marginTop:5}}><span style={{color:trend>=0?C.green:C.red,fontSize:11,fontWeight:700}}>{trend>=0?"▲":"▼"}{Math.abs(trend)}%</span><span style={{color:C.muted,fontSize:10}}> vs last month</span></div>}
    </div>
  );
}
function SCard({title,children,extra}){
  return(
    <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:22}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:15,margin:0}}>{title}</h3>
        {extra}
      </div>
      {children}
    </div>
  );
}
function DTable({headers,rows}){
  return(
    <div style={{overflowX:"auto"}}>
      <table style={{width:"100%",borderCollapse:"collapse"}}>
        <thead><tr>{headers.map(h=><th key={h} style={{textAlign:"left",padding:"8px 11px",color:C.muted,fontSize:10,textTransform:"uppercase",letterSpacing:1,borderBottom:`1px solid ${C.border}`}}>{h}</th>)}</tr></thead>
        <tbody>{rows.map((row,i)=><tr key={i} style={{borderBottom:`1px solid ${C.border}18`}}>{row.map((cell,j)=><td key={j} style={{padding:"10px 11px",color:C.text,fontSize:12}}>{cell}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════
   AUTH — SIGN IN / SIGN UP / SUBSCRIPTION GATE
══════════════════════════════════════════════════════════ */

function AuthGate({ onLogin, users, setUsers, subscribers, setSubscribers }) {
  const [screen, setScreen] = useState("signin"); // signin | signup | subscribe | pay
  const [email,      setEmail]      = useState("");
  const [password,   setPassword]   = useState("");
  const [bizName,    setBizName]    = useState("");
  const [phone,      setPhone]      = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [chosen,     setChosen]     = useState(null);
  const [ref,        setRef]        = useState("");
  const [error,      setError]      = useState("");
  const [loading,    setLoading]    = useState(false);
  const [showPwd,    setShowPwd]    = useState(false);
  const [newUser,    setNewUser]    = useState(null); // holds new user awaiting subscription

  const inp = (val, set, type="text", placeholder="", extra={}) => (
    <div style={{ position:"relative", marginBottom:14 }}>
      <input
        type={type==="password"?(showPwd?"text":"password"):type}
        value={val} onChange={e=>set(e.target.value)}
        placeholder={placeholder}
        style={{ width:"100%", background:C.surface, border:`1px solid ${error?C.red+"55":C.border}`,
          borderRadius:9, padding:"12px 16px", color:C.text, fontSize:13, outline:"none",
          boxSizing:"border-box", fontFamily:"'Barlow',sans-serif" }}
        {...extra}
      />
      {type==="password" && (
        <button onClick={()=>setShowPwd(s=>!s)}
          style={{ position:"absolute", right:12, top:"50%", transform:"translateY(-50%)",
            background:"none", border:"none", color:C.muted, cursor:"pointer", fontSize:13 }}>
          {showPwd?"🙈":"👁"}
        </button>
      )}
    </div>
  );

  // ── SIGN IN ──
  const handleSignIn = () => {
    setError("");
    if(!email.trim()||!password.trim()){ setError("Please enter your email and password."); return; }
    const found = users.find(u => u.email.toLowerCase()===email.trim().toLowerCase() && u.password===password.trim());
    if(!found){ setError("Incorrect email or password. Please try again."); return; }
    // Owner always bypasses subscription check
    if(found.isOwner){
      onLogin(found); return;
    }
    // Check subscription expiry
    if(new Date(found.expiresAt) < new Date()){
      setError("Your subscription has expired. Please renew to continue.");
      setNewUser(found);
      setScreen("subscribe");
      return;
    }
    onLogin(found);
  };

  // ── SIGN UP ──
  const handleSignUp = () => {
    setError("");
    if(!bizName.trim()||!email.trim()||!phone.trim()||!password.trim()||!confirmPwd.trim()){
      setError("Please fill in all fields."); return;
    }
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){
      setError("Please enter a valid email address."); return;
    }
    if(password.length < 6){ setError("Password must be at least 6 characters."); return; }
    if(password !== confirmPwd){ setError("Passwords do not match."); return; }
    if(users.find(u=>u.email.toLowerCase()===email.trim().toLowerCase())){
      setError("An account with this email already exists. Please sign in."); return;
    }
    const nu = { id:Date.now(), email:email.trim(), password, bizName:bizName.trim(), phone:phone.trim(), role:"admin", plan:null, activatedAt:null, expiresAt:null, isOwner:false };
    setNewUser(nu);
    setUsers(prev=>[...prev,nu]);
    setScreen("subscribe");
  };

  // ── SUBSCRIPTION STEP ──
  const goToPay = () => {
    setError("");
    if(!chosen){ setError("Please select a plan."); return; }
    setScreen("pay");
  };

  // ── PAYMENT VERIFY ──
  const verify = () => {
    setError("");
    const trimRef = ref.trim();
    if(!trimRef){ setError("Please enter your MoMo transaction ID."); return; }
    if(!isValidMoMoRef(trimRef)){
      setError("Invalid transaction ID. MTN MoMo transaction IDs are 10–13 digits only (numbers only). Check your confirmation SMS.");
      return;
    }
    // Check duplicate transaction ID
    const alreadyUsed = subscribers.find(s=>s.ref===trimRef);
    if(alreadyUsed){ setError("This transaction ID has already been used. Each ID can only activate one account."); return; }
    setLoading(true);
    setTimeout(()=>{
      setLoading(false);
      const expiry = new Date(Date.now()+30*86400000).toISOString();
      const activated = {...newUser, plan:chosen.id, activatedAt:new Date().toISOString(), expiresAt:expiry, ref:trimRef};
      setUsers(prev=>prev.map(u=>u.id===activated.id?activated:u));
      setSubscribers(prev=>[...prev, activated]);
      onLogin(activated);
    }, 2000);
  };

  const GradBg = () => (
    <div style={{ minHeight:"100vh", background:`radial-gradient(ellipse at 20% 50%,${C.accent}08 0%,transparent 55%),radial-gradient(ellipse at 80% 20%,${C.purple}08 0%,transparent 50%),${C.bg}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32, fontFamily:"'Barlow',sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap');*{box-sizing:border-box;margin:0;padding:0;} input::placeholder{color:#5b7494;}`}</style>
    </div>
  );

  const Logo = () => (
    <div style={{ textAlign:"center", marginBottom:32 }}>
      <div style={{ width:56, height:56, background:`linear-gradient(135deg,${C.accent},${C.cyan})`, borderRadius:16, display:"flex", alignItems:"center", justifyContent:"center", fontSize:26, fontFamily:"'Playfair Display',serif", fontWeight:900, color:C.bg, margin:"0 auto 12px", boxShadow:`0 0 32px ${C.accent}44` }}>M</div>
      <div style={{ color:C.accent, fontFamily:"'Playfair Display',serif", fontWeight:700, fontSize:20 }}>{SYSTEM_NAME}</div>
      <div style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:2 }}>Business Management</div>
    </div>
  );

  // ── RENDER: SIGN IN ──
  if(screen==="signin") return (
    <div style={{ minHeight:"100vh", background:`radial-gradient(ellipse at 20% 50%,${C.accent}08 0%,transparent 55%),radial-gradient(ellipse at 80% 20%,${C.purple}08 0%,transparent 50%),${C.bg}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap');*{box-sizing:border-box;margin:0;padding:0;} input::placeholder{color:#5b7494;}`}</style>
      <Logo/>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:"32px 36px", width:"100%", maxWidth:420 }}>
        <h2 style={{ color:C.text, fontFamily:"'Playfair Display',serif", fontSize:22, marginBottom:6 }}>Welcome Back</h2>
        <p style={{ color:C.muted, fontSize:13, marginBottom:24 }}>Sign in to your account to continue</p>

        <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Email Address</label>
        {inp(email, setEmail, "email", "you@example.com")}
        <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Password</label>
        {inp(password, setPassword, "password", "Your password")}

        {error && <div style={{ background:C.red+"14", border:`1px solid ${C.red}33`, borderRadius:8, padding:"10px 14px", color:C.red, fontSize:12, marginBottom:14 }}>{error}</div>}

        <Btn full color={C.accent} onClick={handleSignIn}>Sign In →</Btn>

        <div style={{ textAlign:"center", marginTop:20, paddingTop:18, borderTop:`1px solid ${C.border}` }}>
          <span style={{ color:C.muted, fontSize:13 }}>Don't have an account? </span>
          <button onClick={()=>{setScreen("signup");setError("");}} style={{ background:"none", border:"none", color:C.accent, fontSize:13, fontWeight:700, cursor:"pointer" }}>Create Account</button>
        </div>

        <div style={{ marginTop:16, background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"12px 16px" }}>
          <p style={{ color:C.muted, fontSize:11, textAlign:"center", marginBottom:6, textTransform:"uppercase", letterSpacing:1 }}>Owner Access</p>
          <p style={{ color:C.dim, fontSize:11, textAlign:"center" }}>Email: <span style={{ color:C.accent }}>{OWNER.email}</span></p>
          <p style={{ color:C.dim, fontSize:11, textAlign:"center", marginTop:3 }}>Contact system owner for credentials</p>
        </div>
      </div>
      <p style={{ color:C.muted, fontSize:11, marginTop:24 }}>© {new Date().getFullYear()} Makin Limited · v{SYSTEM_VERSION}</p>
    </div>
  );

  // ── RENDER: SIGN UP ──
  if(screen==="signup") return (
    <div style={{ minHeight:"100vh", background:`radial-gradient(ellipse at 20% 50%,${C.accent}08 0%,transparent 55%),radial-gradient(ellipse at 80% 20%,${C.purple}08 0%,transparent 50%),${C.bg}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap');*{box-sizing:border-box;margin:0;padding:0;} input::placeholder{color:#5b7494;}`}</style>
      <Logo/>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:"32px 36px", width:"100%", maxWidth:460 }}>
        <h2 style={{ color:C.text, fontFamily:"'Playfair Display',serif", fontSize:22, marginBottom:6 }}>Create Account</h2>
        <p style={{ color:C.muted, fontSize:13, marginBottom:24 }}>Set up your Makin BizSystem account</p>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:0 }}>
          <div>
            <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Business Name</label>
            <input value={bizName} onChange={e=>setBizName(e.target.value)} placeholder="e.g. Kofi Stores" style={{ width:"100%", background:C.surface, border:`1px solid ${C.border}`, borderRadius:9, padding:"11px 14px", color:C.text, fontSize:13, outline:"none", boxSizing:"border-box", marginBottom:14 }}/>
          </div>
          <div>
            <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Phone Number</label>
            <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="e.g. 0244123456" style={{ width:"100%", background:C.surface, border:`1px solid ${C.border}`, borderRadius:9, padding:"11px 14px", color:C.text, fontSize:13, outline:"none", boxSizing:"border-box", marginBottom:14 }}/>
          </div>
        </div>

        <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Email Address</label>
        {inp(email, setEmail, "email", "you@example.com")}
        <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Password</label>
        {inp(password, setPassword, "password", "Min. 6 characters")}
        <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>Confirm Password</label>
        {inp(confirmPwd, setConfirmPwd, "password", "Re-enter password")}

        {error && <div style={{ background:C.red+"14", border:`1px solid ${C.red}33`, borderRadius:8, padding:"10px 14px", color:C.red, fontSize:12, marginBottom:14 }}>{error}</div>}

        <Btn full color={C.accent} onClick={handleSignUp}>Continue to Subscription →</Btn>

        <div style={{ textAlign:"center", marginTop:18, paddingTop:16, borderTop:`1px solid ${C.border}` }}>
          <span style={{ color:C.muted, fontSize:13 }}>Already have an account? </span>
          <button onClick={()=>{setScreen("signin");setError("");}} style={{ background:"none", border:"none", color:C.accent, fontSize:13, fontWeight:700, cursor:"pointer" }}>Sign In</button>
        </div>
      </div>
    </div>
  );

  // ── RENDER: SUBSCRIPTION PLAN PICKER ──
  if(screen==="subscribe") return (
    <div style={{ minHeight:"100vh", background:`radial-gradient(ellipse at 20% 50%,${C.accent}08 0%,transparent 55%),radial-gradient(ellipse at 80% 20%,${C.purple}08 0%,transparent 50%),${C.bg}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap');*{box-sizing:border-box;margin:0;padding:0;} input::placeholder{color:#5b7494;}`}</style>
      <Logo/>
      <h2 style={{ color:C.text, fontFamily:"'Playfair Display',serif", marginBottom:24, fontSize:19, textAlign:"center" }}>Choose Your Plan</h2>
      <div style={{ display:"flex", gap:18, flexWrap:"wrap", justifyContent:"center", maxWidth:900, marginBottom:28 }}>
        {PLANS.map(plan=>(
          <div key={plan.id} onClick={()=>setChosen(plan)} style={{ background:chosen?.id===plan.id?plan.color+"18":C.card, border:`2px solid ${chosen?.id===plan.id?plan.color:C.border}`, borderRadius:18, padding:26, width:255, cursor:"pointer", transition:"all 0.2s", position:"relative" }}>
            {plan.badge&&<div style={{ position:"absolute", top:-11, left:"50%", transform:"translateX(-50%)", background:plan.color, color:C.bg, borderRadius:20, padding:"3px 13px", fontSize:10, fontWeight:800, letterSpacing:1, whiteSpace:"nowrap" }}>{plan.badge}</div>}
            <div style={{ color:plan.color, fontFamily:"'Playfair Display',serif", fontSize:21, fontWeight:700, marginBottom:4 }}>{plan.name}</div>
            <div style={{ marginBottom:18 }}><span style={{ color:C.text, fontSize:30, fontWeight:800 }}>GH₵{plan.price}</span><span style={{ color:C.muted, fontSize:12 }}>/month</span></div>
            {plan.features.map(f=><div key={f} style={{ display:"flex", gap:8, marginBottom:7, alignItems:"flex-start" }}><span style={{ color:plan.color, fontSize:12, marginTop:1 }}>✓</span><span style={{ color:C.muted, fontSize:12, lineHeight:1.4 }}>{f}</span></div>)}
          </div>
        ))}
      </div>
      {error && <div style={{ background:C.red+"14", border:`1px solid ${C.red}33`, borderRadius:8, padding:"10px 14px", color:C.red, fontSize:12, marginBottom:14, maxWidth:420, width:"100%" }}>{error}</div>}
      <div style={{ display:"flex", gap:12 }}>
        <Btn outline color={C.muted} onClick={()=>{setScreen("signin");setError("");}}>← Back to Sign In</Btn>
        <Btn color={C.accent} onClick={goToPay}>Continue to Payment →</Btn>
      </div>
    </div>
  );

  // ── RENDER: PAYMENT ──
  if(screen==="pay") return (
    <div style={{ minHeight:"100vh", background:`radial-gradient(ellipse at 20% 50%,${C.accent}08 0%,transparent 55%),radial-gradient(ellipse at 80% 20%,${C.purple}08 0%,transparent 50%),${C.bg}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:32 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap');*{box-sizing:border-box;margin:0;padding:0;} input::placeholder{color:#5b7494;}`}</style>
      <Logo/>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:34, maxWidth:470, width:"100%" }}>
        <h2 style={{ color:C.accent, fontFamily:"'Playfair Display',serif", fontSize:21, marginBottom:5 }}>Make Payment</h2>
        <p style={{ color:C.muted, fontSize:13, marginBottom:22 }}>Send your subscription fee via Mobile Money, then enter your transaction ID below.</p>
        <div style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:12, padding:18, marginBottom:18 }}>
          {[["Network",OWNER_MOMO.network],["MoMo Number",OWNER_MOMO.number],["Account Name",OWNER_MOMO.name],["Amount",`GH₵${chosen.price}`],["Plan",`${chosen.name} · 1 Month`]].map(([k,v])=>(
            <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${C.border}20` }}>
              <span style={{ color:C.muted, fontSize:13 }}>{k}</span>
              <span style={{ color:k==="Amount"?C.green:k==="MoMo Number"?C.accent:C.text, fontWeight:k==="Amount"||k==="MoMo Number"?800:500, fontSize:13 }}>{v}</span>
            </div>
          ))}
        </div>
        <div style={{ background:C.gold+"12", border:`1px solid ${C.gold}33`, borderRadius:10, padding:13, marginBottom:18, color:C.gold, fontSize:12, lineHeight:1.7 }}>
          <strong>How to pay (MTN MoMo):</strong><br/>
          1. Dial <strong>*170#</strong> → Transfer Money → To MoMo User<br/>
          2. Enter number: <strong>{OWNER_MOMO.number}</strong><br/>
          3. Enter amount: <strong>GH₵{chosen.price}</strong><br/>
          4. Your confirmation SMS contains a <strong>10–13 digit Transaction ID</strong>
        </div>

        <label style={{ color:C.muted, fontSize:11, textTransform:"uppercase", letterSpacing:1, display:"block", marginBottom:6 }}>MoMo Transaction ID</label>
        <input
          value={ref} onChange={e=>setRef(e.target.value.replace(/\D/g,""))}
          placeholder="10–13 digit number from your SMS"
          maxLength={13}
          style={{ width:"100%", background:C.surface, border:`1px solid ${error?C.red:C.border}`, borderRadius:9, padding:"12px 16px", color:C.text, fontSize:14, outline:"none", boxSizing:"border-box", marginBottom:6, fontFamily:"'Space Mono',monospace", letterSpacing:2 }}
        />
        <p style={{ color:C.muted, fontSize:11, marginBottom:14 }}>Numbers only · Example: 2401234567890</p>

        {error && <div style={{ background:C.red+"14", border:`1px solid ${C.red}33`, borderRadius:8, padding:"10px 14px", color:C.red, fontSize:12, marginBottom:14 }}>{error}</div>}
        {loading && <p style={{ color:C.muted, fontSize:12, marginBottom:10 }}>⏳ Verifying, please wait...</p>}

        <div style={{ display:"flex", gap:10 }}>
          <Btn outline color={C.muted} onClick={()=>{setScreen("subscribe");setError("");}}>← Back</Btn>
          <Btn color={C.green} onClick={verify}>{loading?"Verifying...":"Activate System ✓"}</Btn>
        </div>
      </div>
    </div>
  );

  return null;
}

/* ══════════════════════════════════════════════════════════
   EXPORT UTILITIES  (Excel via SheetJS · PDF via print)
══════════════════════════════════════════════════════════ */

/* Full JSON backup – used for import/restore */
function exportData(data){
  const blob=new Blob([JSON.stringify({version:2,exportedAt:new Date().toISOString(),data},null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download=`makin-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();
  URL.revokeObjectURL(url);
}

/* ── Excel helpers ── */
function toExcel(sheets, filename){
  const wb = XLSX.utils.book_new();
  sheets.forEach(({name, rows, headers})=>{
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    // Column widths
    ws["!cols"] = headers.map(()=>({wch:20}));
    XLSX.utils.book_append_sheet(wb, ws, name.slice(0,31));
  });
  XLSX.writeFile(wb, filename, { bookType: "xls" });
}

function exportInventoryExcel(inventory){
  toExcel([{
    name:"Inventory",
    headers:["Item","Category","Qty","Unit","Cost Price (GH₵)","Selling Price (GH₵)","Margin %","Reorder Level","Status","Stock Value (GH₵)"],
    rows: inventory.map(i=>[i.name,i.category,i.qty,i.unit,i.cost,i.price,Math.round((i.price-i.cost)/i.price*100)+"%",i.reorder,i.qty<=i.reorder?"Low Stock":"In Stock",(i.qty*i.cost).toFixed(2)])
  }], `inventory-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportSalesExcel(sales){
  const summary = sales.map(s=>[s.id,s.date,s.customer,s.items.map(i=>`${i.name}×${i.qty}`).join("; "),s.total,s.status]);
  const detail  = sales.flatMap(s=>s.items.map(i=>[s.id,s.date,s.customer,i.name,i.qty,i.price,(i.qty*i.price).toFixed(2),s.status]));
  toExcel([
    {name:"Sales Summary", headers:["Invoice #","Date","Customer","Items","Total (GH₵)","Status"], rows:summary},
    {name:"Sales Detail",  headers:["Invoice #","Date","Customer","Item","Qty","Unit Price","Line Total","Status"], rows:detail},
  ], `sales-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportPurchasesExcel(purchases){
  const summary = purchases.map(p=>[p.id,p.date,p.supplier,p.items.map(i=>`${i.name}×${i.qty}`).join("; "),p.total,p.status]);
  const detail  = purchases.flatMap(p=>p.items.map(i=>[p.id,p.date,p.supplier,i.name,i.qty,i.cost,(i.qty*i.cost).toFixed(2),p.status]));
  toExcel([
    {name:"Purchase Summary", headers:["Order #","Date","Supplier","Items","Total (GH₵)","Status"], rows:summary},
    {name:"Purchase Detail",  headers:["Order #","Date","Supplier","Item","Qty","Unit Cost","Line Total","Status"], rows:detail},
  ], `purchases-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportCustomersExcel(customers){
  toExcel([{
    name:"Customers",
    headers:["Business Name","Contact Person","Phone","Email","Address","Balance (GH₵)","Total Bought (GH₵)"],
    rows: customers.map(c=>[c.name,c.contact,c.phone,c.email,c.address,c.balance,c.totalBought||0])
  }], `customers-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportSuppliersExcel(suppliers){
  toExcel([{
    name:"Suppliers",
    headers:["Company","Contact","Phone","Email","Products","Balance Owed (GH₵)"],
    rows: suppliers.map(s=>[s.name,s.contact,s.phone,s.email,s.product,s.balance])
  }], `suppliers-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportExpensesExcel(expenses){
  const total=expenses.reduce((a,e)=>a+e.amount,0);
  const byCat=expenses.reduce((acc,e)=>{acc[e.category]=(acc[e.category]||0)+e.amount;return acc;},{});
  toExcel([
    {name:"Expenses", headers:["Date","Category","Description","Amount (GH₵)"], rows:expenses.map(e=>[e.date,e.category,e.description,e.amount]).concat([["","","TOTAL",total]])},
    {name:"By Category", headers:["Category","Total (GH₵)"], rows:Object.entries(byCat)},
  ], `expenses-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportStaffExcel(staff){
  toExcel([{
    name:"Staff",
    headers:["Name","Role","Email","Phone","Monthly Salary (GH₵)","Status"],
    rows: staff.map(s=>[s.name,s.role,s.email,s.phone,s.salary||0,s.status])
  }], `staff-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportDeliveriesExcel(deliveries){
  toExcel([{
    name:"Deliveries",
    headers:["ID","Date","Customer","Invoice #","Driver","Address","Status"],
    rows:(deliveries||[]).map(d=>[d.id,d.date,d.customer,d.invoice||"",d.driver,d.address,d.status])
  }], `deliveries-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportAuditExcel(auditLog){
  toExcel([{
    name:"Audit Trail",
    headers:["#","Timestamp","Action","Module","Description","User","Session"],
    rows:auditLog.map(e=>[e.id,e.timestamp,e.action,e.module,e.description,e.user,e.session])
  }], `audit-trail-${new Date().toISOString().slice(0,10)}.xls`);
}

function exportFullWorkbook(data){
  toExcel([
    {name:"Inventory",  headers:["Item","Category","Qty","Unit","Cost","Price","Status"],           rows:data.inventory.map(i=>[i.name,i.category,i.qty,i.unit,i.cost,i.price,i.qty<=i.reorder?"Low Stock":"In Stock"])},
    {name:"Sales",      headers:["Invoice","Date","Customer","Total","Status"],                     rows:data.sales.map(s=>[s.id,s.date,s.customer,s.total,s.status])},
    {name:"Purchases",  headers:["Order","Date","Supplier","Total","Status"],                       rows:data.purchases.map(p=>[p.id,p.date,p.supplier,p.total,p.status])},
    {name:"Customers",  headers:["Name","Contact","Phone","Email","Balance"],                       rows:data.customers.map(c=>[c.name,c.contact,c.phone,c.email,c.balance])},
    {name:"Suppliers",  headers:["Name","Contact","Phone","Email","Balance"],                       rows:data.suppliers.map(s=>[s.name,s.contact,s.phone,s.email,s.balance])},
    {name:"Expenses",   headers:["Date","Category","Description","Amount"],                         rows:data.expenses.map(e=>[e.date,e.category,e.description,e.amount])},
    {name:"Staff",      headers:["Name","Role","Email","Phone","Salary","Status"],                  rows:data.staff.map(s=>[s.name,s.role,s.email,s.phone,s.salary||0,s.status])},
    {name:"Deliveries", headers:["ID","Date","Customer","Driver","Status"],                         rows:(data.deliveries||[]).map(d=>[d.id,d.date,d.customer,d.driver,d.status])},
  ], `makin-full-export-${new Date().toISOString().slice(0,10)}.xls`);
}

/* ── PDF helpers (print-to-PDF via browser) ── */
function printPDF(htmlContent, title){
  const win=window.open("","_blank");
  win.document.write(`<!DOCTYPE html><html><head><title>${title}</title><style>
    *{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:Arial,sans-serif;font-size:11px;color:#111;padding:24px;}
    h1{font-size:18px;margin-bottom:4px;color:#00a882;}
    .subtitle{color:#666;font-size:10px;margin-bottom:16px;}
    .meta{display:flex;gap:24px;margin-bottom:20px;padding:10px;background:#f5f5f5;border-radius:6px;}
    .meta span{font-size:10px;color:#555;}
    .meta strong{color:#111;}
    table{width:100%;border-collapse:collapse;margin-bottom:20px;}
    th{background:#0a1828;color:#fff;padding:7px 10px;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;}
    td{padding:6px 10px;border-bottom:1px solid #e8e8e8;font-size:10px;}
    tr:nth-child(even) td{background:#fafafa;}
    .total-row td{font-weight:bold;background:#f0fdf4;border-top:2px solid #00a882;}
    .badge{display:inline-block;padding:2px 7px;border-radius:4px;font-size:9px;font-weight:bold;text-transform:uppercase;}
    .badge-green{background:#dcfce7;color:#16a34a;}
    .badge-red{background:#fee2e2;color:#dc2626;}
    .badge-gold{background:#fef9c3;color:#b45309;}
    .badge-blue{background:#dbeafe;color:#1d4ed8;}
    .footer{margin-top:30px;padding-top:12px;border-top:1px solid #e8e8e8;display:flex;justify-content:space-between;color:#999;font-size:9px;}
    .summary-box{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px;}
    .summary-item{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px;}
    .summary-item .val{font-size:18px;font-weight:bold;color:#00a882;margin-bottom:2px;}
    .summary-item .lbl{font-size:9px;color:#666;text-transform:uppercase;}
    @media print{body{padding:16px;}}
  </style></head><body>${htmlContent}
  <div class="footer"><span>${SYSTEM_NAME} v${SYSTEM_VERSION}</span><span>Generated: ${new Date().toLocaleString()}</span><span>Makin Limited · MoMo: ${OWNER_MOMO.number}</span></div>
  <script>window.onload=()=>{window.print();}<\/script></body></html>`);
  win.document.close();
}

function exportSalesPDF(sales){
  const total=sales.reduce((a,s)=>a+s.total,0);
  const paid=sales.filter(s=>s.status==="paid").reduce((a,s)=>a+s.total,0);
  const unpaid=sales.filter(s=>s.status==="unpaid").reduce((a,s)=>a+s.total,0);
  const html=`
    <h1>Sales & Invoices Report</h1>
    <p class="subtitle">Makin Limited · ${new Date().toLocaleDateString()}</p>
    <div class="summary-box">
      <div class="summary-item"><div class="val">GH₵${total.toLocaleString()}</div><div class="lbl">Total Revenue</div></div>
      <div class="summary-item"><div class="val" style="color:#16a34a">GH₵${paid.toLocaleString()}</div><div class="lbl">Collected</div></div>
      <div class="summary-item"><div class="val" style="color:#b45309">GH₵${unpaid.toLocaleString()}</div><div class="lbl">Outstanding</div></div>
      <div class="summary-item"><div class="val">${sales.length}</div><div class="lbl">Invoices</div></div>
    </div>
    <table><thead><tr><th>Invoice #</th><th>Date</th><th>Customer</th><th>Items</th><th>Total (GH₵)</th><th>Status</th></tr></thead>
    <tbody>${sales.map(s=>`<tr><td><strong>#${s.id}</strong></td><td>${s.date}</td><td>${s.customer}</td><td>${s.items.map(i=>i.name+"×"+i.qty).join(", ")}</td><td><strong>${s.total.toLocaleString()}</strong></td><td><span class="badge ${s.status==="paid"?"badge-green":"badge-gold"}">${s.status}</span></td></tr>`).join("")}
    <tr class="total-row"><td colspan="4">TOTAL</td><td>GH₵${total.toLocaleString()}</td><td></td></tr></tbody></table>`;
  printPDF(html,"Sales Report - Makin Limited");
}

function exportPurchasesPDF(purchases){
  const total=purchases.reduce((a,p)=>a+p.total,0);
  const html=`
    <h1>Purchase Orders Report</h1>
    <p class="subtitle">Makin Limited · ${new Date().toLocaleDateString()}</p>
    <div class="summary-box">
      <div class="summary-item"><div class="val">GH₵${total.toLocaleString()}</div><div class="lbl">Total Purchased</div></div>
      <div class="summary-item"><div class="val" style="color:#16a34a">${purchases.filter(p=>p.status==="paid").length}</div><div class="lbl">Paid Orders</div></div>
      <div class="summary-item"><div class="val" style="color:#dc2626">${purchases.filter(p=>p.status==="unpaid").length}</div><div class="lbl">Unpaid Orders</div></div>
      <div class="summary-item"><div class="val">${purchases.length}</div><div class="lbl">Total Orders</div></div>
    </div>
    <table><thead><tr><th>Order #</th><th>Date</th><th>Supplier</th><th>Items</th><th>Total (GH₵)</th><th>Status</th></tr></thead>
    <tbody>${purchases.map(p=>`<tr><td><strong>#${p.id}</strong></td><td>${p.date}</td><td>${p.supplier}</td><td>${p.items.map(i=>i.name+"×"+i.qty).join(", ")}</td><td><strong>${p.total.toLocaleString()}</strong></td><td><span class="badge ${p.status==="paid"?"badge-green":"badge-red"}">${p.status}</span></td></tr>`).join("")}
    <tr class="total-row"><td colspan="4">TOTAL</td><td>GH₵${total.toLocaleString()}</td><td></td></tr></tbody></table>`;
  printPDF(html,"Purchase Orders - Makin Limited");
}

function exportInventoryPDF(inventory){
  const stockVal=inventory.reduce((a,i)=>a+i.qty*i.cost,0);
  const low=inventory.filter(i=>i.qty<=i.reorder);
  const html=`
    <h1>Inventory Report</h1>
    <p class="subtitle">Makin Limited · ${new Date().toLocaleDateString()}</p>
    <div class="summary-box">
      <div class="summary-item"><div class="val">${inventory.length}</div><div class="lbl">Total Items</div></div>
      <div class="summary-item"><div class="val">GH₵${stockVal.toLocaleString()}</div><div class="lbl">Stock Value</div></div>
      <div class="summary-item"><div class="val" style="color:#dc2626">${low.length}</div><div class="lbl">Low Stock</div></div>
      <div class="summary-item"><div class="val">${inventory.filter(i=>i.qty>i.reorder).length}</div><div class="lbl">Well Stocked</div></div>
    </div>
    <table><thead><tr><th>Item</th><th>Category</th><th>Qty</th><th>Unit</th><th>Cost (GH₵)</th><th>Sell Price (GH₵)</th><th>Margin</th><th>Reorder</th><th>Status</th></tr></thead>
    <tbody>${inventory.map(i=>`<tr><td><strong>${i.name}</strong></td><td>${i.category}</td><td>${i.qty}</td><td>${i.unit}</td><td>${i.cost}</td><td>${i.price}</td><td>${Math.round((i.price-i.cost)/i.price*100)}%</td><td>${i.reorder}</td><td><span class="badge ${i.qty<=i.reorder?"badge-red":"badge-green"}">${i.qty<=i.reorder?"Low Stock":"In Stock"}</span></td></tr>`).join("")}</tbody></table>`;
  printPDF(html,"Inventory Report - Makin Limited");
}

function exportReportsPDF(data){
  const totalSales=data.sales.reduce((a,s)=>a+s.total,0);
  const totalPurch=data.purchases.reduce((a,p)=>a+p.total,0);
  const totalExp=data.expenses.reduce((a,e)=>a+e.amount,0);
  const gross=totalSales-totalPurch;
  const net=gross-totalExp;
  const expByCat=data.expenses.reduce((acc,e)=>{acc[e.category]=(acc[e.category]||0)+e.amount;return acc;},{});
  const html=`
    <h1>Financial Report — Profit & Loss</h1>
    <p class="subtitle">Makin Limited · ${new Date().toLocaleDateString()}</p>
    <div class="summary-box">
      <div class="summary-item"><div class="val">GH₵${totalSales.toLocaleString()}</div><div class="lbl">Total Revenue</div></div>
      <div class="summary-item"><div class="val" style="color:#dc2626">GH₵${totalPurch.toLocaleString()}</div><div class="lbl">Cost of Goods</div></div>
      <div class="summary-item"><div class="val" style="color:#1d4ed8">GH₵${gross.toLocaleString()}</div><div class="lbl">Gross Profit</div></div>
      <div class="summary-item"><div class="val" style="color:${net>=0?"#00a882":"#dc2626"}">GH₵${net.toLocaleString()}</div><div class="lbl">Net Profit</div></div>
    </div>
    <h2 style="font-size:13px;margin-bottom:10px;color:#333;">P&amp;L Summary</h2>
    <table><thead><tr><th>Item</th><th>Amount (GH₵)</th></tr></thead>
    <tbody>
      <tr><td>Total Revenue</td><td>${totalSales.toLocaleString()}</td></tr>
      <tr><td>Cost of Goods Sold</td><td>${totalPurch.toLocaleString()}</td></tr>
      <tr><td><strong>Gross Profit</strong></td><td><strong>${gross.toLocaleString()}</strong></td></tr>
      <tr><td>Operating Expenses</td><td>${totalExp.toLocaleString()}</td></tr>
      <tr class="total-row"><td>Net Profit / Loss</td><td>GH₵${net.toLocaleString()}</td></tr>
    </tbody></table>
    <h2 style="font-size:13px;margin-bottom:10px;color:#333;">Expense Breakdown</h2>
    <table><thead><tr><th>Category</th><th>Amount (GH₵)</th><th>% of Total</th></tr></thead>
    <tbody>${Object.entries(expByCat).map(([cat,amt])=>`<tr><td>${cat}</td><td>${amt.toLocaleString()}</td><td>${Math.round(amt/totalExp*100)}%</td></tr>`).join("")}</tbody></table>`;
  printPDF(html,"Financial Report - Makin Limited");
}

function exportAuditPDF(auditLog){
  const html=`
    <h1>Audit Trail Report</h1>
    <p class="subtitle">Makin Limited · ${new Date().toLocaleDateString()} · ${auditLog.length} entries</p>
    <table><thead><tr><th>#</th><th>Time</th><th>Action</th><th>Module</th><th>Description</th><th>User</th></tr></thead>
    <tbody>${[...auditLog].reverse().map(e=>`<tr><td>${e.id}</td><td style="white-space:nowrap">${e.timestamp}</td><td><span class="badge ${e.action==="CREATE"?"badge-green":e.action==="DELETE"?"badge-red":e.action==="PAYMENT"?"badge-gold":"badge-blue"}">${e.action}</span></td><td>${e.module}</td><td>${e.description}</td><td>${e.user}</td></tr>`).join("")}</tbody></table>`;
  printPDF(html,"Audit Trail - Makin Limited");
}

function exportInvoicePDF(sale){
  const html=`
    <h1>Invoice #${sale.id}</h1>
    <p class="subtitle">Makin Limited · ${sale.date}</p>
    <div class="meta">
      <span><strong>Bill To:</strong> ${sale.customer}</span>
      <span><strong>Date:</strong> ${sale.date}</span>
      <span><strong>Status:</strong> <span class="badge ${sale.status==="paid"?"badge-green":"badge-gold"}">${sale.status.toUpperCase()}</span></span>
    </div>
    <table><thead><tr><th>Item</th><th>Qty</th><th>Unit Price (GH₵)</th><th>Total (GH₵)</th></tr></thead>
    <tbody>${sale.items.map(i=>`<tr><td>${i.name}</td><td>${i.qty}</td><td>${i.price}</td><td>${(i.qty*i.price).toLocaleString()}</td></tr>`).join("")}
    <tr class="total-row"><td colspan="3">TOTAL</td><td>GH₵${sale.total.toLocaleString()}</td></tr></tbody></table>
    <div class="meta" style="margin-top:20px">
      <span><strong>Payment via:</strong> ${OWNER_MOMO.network}</span>
      <span><strong>MoMo Number:</strong> ${OWNER_MOMO.number}</span>
      <span><strong>Account:</strong> ${OWNER_MOMO.name}</span>
    </div>`;
  printPDF(html,`Invoice #${sale.id} - Makin Limited`);
}

/* ── ExportMenu component – reusable dropdown ── */
function ExportMenu({ options }){
  const [open,setOpen]=useState(false);
  return(
    <div style={{position:"relative"}}>
      <button onClick={()=>setOpen(o=>!o)} style={{background:C.dim,border:`1px solid ${C.border}`,borderRadius:8,color:C.text,padding:"7px 14px",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:0.5,display:"flex",alignItems:"center",gap:6}}>
        ⬇ Export {open?"▲":"▼"}
      </button>
      {open&&(
        <div style={{position:"absolute",right:0,top:36,background:C.card,border:`1px solid ${C.border}`,borderRadius:12,minWidth:210,zIndex:200,boxShadow:"0 8px 32px #00000070",overflow:"hidden"}}>
          {options.map((opt,i)=>(
            <button key={i} onClick={()=>{opt.action();setOpen(false);}} style={{width:"100%",background:"none",border:"none",padding:"10px 16px",color:C.text,fontSize:12,cursor:"pointer",display:"flex",alignItems:"center",gap:10,textAlign:"left",borderBottom:i<options.length-1?`1px solid ${C.border}14`:"none"}}>
              <span style={{fontSize:15}}>{opt.icon}</span>
              <div>
                <div style={{fontWeight:600}}>{opt.label}</div>
                <div style={{color:C.muted,fontSize:10}}>{opt.desc}</div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── TopBar ── */
function TopBar({data,setData,notifications,setNotifications,bizName,role,onLogout}){
  const [msg,setMsg]=useState(null);
  const [showN,setShowN]=useState(false);
  const unread=notifications.filter(n=>!n.read).length;

  const handleImport=e=>{
    const file=e.target.files[0];if(!file)return;
    const r=new FileReader();
    r.onload=ev=>{
      try{
        if(file.name.endsWith(".json")){
          const p=JSON.parse(ev.target.result);if(!p.data)throw 0;setData(p.data);setMsg({t:"ok",m:"✓ JSON backup restored!"});
        } else {
          const wb=XLSX.read(ev.target.result,{type:"binary"});
          const newData={...data};
          const sheetMap={Inventory:"inventory",Sales:"sales",Purchases:"purchases",Customers:"customers",Suppliers:"suppliers",Expenses:"expenses",Staff:"staff",Deliveries:"deliveries"};
          wb.SheetNames.forEach(name=>{
            const key=sheetMap[name];
            if(key){ const rows=XLSX.utils.sheet_to_json(wb.Sheets[name]); if(rows.length) newData[key]=rows; }
          });
          setData(newData);setMsg({t:"ok",m:"✓ Excel data imported!"});
        }
      }catch{setMsg({t:"err",m:"✗ Invalid file"});}
      setTimeout(()=>setMsg(null),3000);
    };
    if(file.name.endsWith(".json")) r.readAsText(file);
    else r.readAsBinaryString(file);
    e.target.value="";
  };

  return(
    <div style={{background:C.surface,borderBottom:`1px solid ${C.border}`,padding:"9px 26px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{color:C.muted,fontSize:13}}>Welcome, <span style={{color:C.accent,fontWeight:700}}>{bizName}</span></span>
          {role&&<span style={{background:role==="owner"?C.purple+"22":role==="admin"?C.accent+"22":C.blue+"22",color:role==="owner"?C.purple:role==="admin"?C.accent:C.blue,border:`1px solid ${role==="owner"?C.purple+"44":role==="admin"?C.accent+"44":C.blue+"44"}`,borderRadius:20,padding:"2px 10px",fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:1}}>{role}</span>}
        </div>
      <div style={{display:"flex",alignItems:"center",gap:8}}>
        {msg&&<span style={{color:msg.t==="ok"?C.green:C.red,fontSize:12,fontWeight:600}}>{msg.m}</span>}

        {/* Export dropdown */}
        <ExportMenu options={[
          {icon:"📊",label:"Full Excel Workbook",  desc:"All modules in one .xls file",  action:()=>exportFullWorkbook(data)},
          {icon:"💾",label:"JSON Backup",           desc:"Full data backup (.json)",        action:()=>exportData(data)},
        ]}/>

        {/* Import */}
        <label style={{cursor:"pointer"}}>
          <input type="file" accept=".json,.xls" onChange={handleImport} style={{display:"none"}}/>
          <span style={{background:"transparent",color:C.green,border:`1.5px solid ${C.green}`,borderRadius:8,padding:"6px 12px",fontWeight:700,fontSize:11,cursor:"pointer",fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:1}}>⬆ Import</span>
        </label>

        {/* Notifications */}
        <div style={{position:"relative"}}>
          <button onClick={()=>setShowN(s=>!s)} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:8,color:C.text,padding:"6px 11px",cursor:"pointer",fontSize:15,position:"relative"}}>
            🔔{unread>0&&<span style={{position:"absolute",top:-5,right:-5,background:C.red,color:"#fff",borderRadius:"50%",width:15,height:15,fontSize:9,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800}}>{unread}</span>}
          </button>
          {showN&&(
            <div style={{position:"absolute",right:0,top:38,background:C.card,border:`1px solid ${C.border}`,borderRadius:14,width:300,zIndex:500,boxShadow:"0 8px 40px #00000060"}}>
              <div style={{padding:"12px 16px",borderBottom:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{color:C.text,fontWeight:700,fontSize:13}}>Notifications</span>
                <button onClick={()=>setNotifications(n=>n.map(x=>({...x,read:true})))} style={{background:"none",border:"none",color:C.accent,fontSize:11,cursor:"pointer"}}>Mark all read</button>
              </div>
              {notifications.map(n=>(
                <div key={n.id} style={{padding:"11px 16px",borderBottom:`1px solid ${C.border}15`,background:n.read?"transparent":C.accent+"08"}}>
                  <div style={{color:C.text,fontSize:12}}>{n.message}</div>
                  <div style={{color:C.muted,fontSize:10,marginTop:2}}>{n.time}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Logout */}
        <button onClick={onLogout} title="Sign out" style={{background:"none",border:`1px solid ${C.red}55`,borderRadius:8,color:C.red,padding:"6px 13px",cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"'Barlow Condensed',sans-serif",letterSpacing:0.5,display:"flex",alignItems:"center",gap:5,transition:"all 0.15s"}}
          onMouseEnter={e=>{e.currentTarget.style.background=C.red+"18";}}
          onMouseLeave={e=>{e.currentTarget.style.background="none";}}>
          ⏻ Logout
        </button>
      </div>
    </div>
  );
}

/* ── DASHBOARD ── */
function Dashboard({data}){
  const MK=["2025-09","2025-10","2025-11","2025-12","2026-01","2026-02","2026-03"];
  const ML=["Sep","Oct","Nov","Dec","Jan","Feb","Mar"];
  const byMonth=MK.map((mk,i)=>({
    month:ML[i],
    sales:data.sales.filter(s=>s.date.startsWith(mk)).reduce((a,s)=>a+s.total,0),
    purchases:data.purchases.filter(p=>p.date.startsWith(mk)).reduce((a,p)=>a+p.total,0),
  }));
  const expByCat=data.expenses.reduce((acc,e)=>{acc[e.category]=(acc[e.category]||0)+e.amount;return acc;},{});
  const pieData=Object.entries(expByCat).map(([name,value])=>({name,value}));
  const PC=[C.red,C.orange,C.purple,C.blue,C.cyan,C.accent];
  const totalSales=data.sales.reduce((a,s)=>a+s.total,0);
  const totalPurch=data.purchases.reduce((a,p)=>a+p.total,0);
  const totalExp=data.expenses.reduce((a,e)=>a+e.amount,0);
  const netProfit=totalSales-totalPurch-totalExp;
  const unpaid=data.sales.filter(s=>s.status==="unpaid").reduce((a,s)=>a+s.total,0);
  const lowStock=data.inventory.filter(i=>i.qty<=i.reorder);
  const topCust=[...data.customers].sort((a,b)=>(b.totalBought||0)-(a.totalBought||0));
  const maxB=topCust[0]?.totalBought||1;
  const stockData=data.inventory.map(i=>({name:i.name.split(" ")[0],qty:i.qty,reorder:i.reorder}));

  return(
    <div>
      <div style={{marginBottom:24}}>
        <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:27,marginBottom:3}}>Business Dashboard</h2>
        <p style={{color:C.muted,fontSize:13}}>{new Date().toLocaleDateString("en-GH",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</p>
      </div>
      <div style={{display:"flex",gap:13,flexWrap:"wrap",marginBottom:22}}>
        <KCard label="Total Revenue"   value={`GH₵${totalSales.toLocaleString()}`}   color={C.green}  icon="◈" trend={12}/>
        <KCard label="Total Purchases" value={`GH₵${totalPurch.toLocaleString()}`}   color={C.blue}   icon="◉" trend={-3}/>
        <KCard label="Total Expenses"  value={`GH₵${totalExp.toLocaleString()}`}     color={C.orange} icon="◑"/>
        <KCard label="Net Profit"      value={`GH₵${netProfit.toLocaleString()}`}    color={netProfit>=0?C.accent:C.red} icon="◎" trend={8}/>
        <KCard label="Outstanding"     value={`GH₵${unpaid.toLocaleString()}`}       color={C.gold}   icon="⏳"/>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:16,marginBottom:16}}>
        <SCard title="📈 Revenue vs Purchases">
          <ResponsiveContainer width="100%" height={210}>
            <AreaChart data={byMonth}>
              <defs>
                <linearGradient id="gs" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={C.accent} stopOpacity={0.3}/><stop offset="95%" stopColor={C.accent} stopOpacity={0}/></linearGradient>
                <linearGradient id="gp" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={C.blue} stopOpacity={0.3}/><stop offset="95%" stopColor={C.blue} stopOpacity={0}/></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
              <XAxis dataKey="month" stroke={C.muted} tick={{fill:C.muted,fontSize:10}}/>
              <YAxis stroke={C.muted} tick={{fill:C.muted,fontSize:10}} tickFormatter={v=>`₵${v}`}/>
              <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text}} formatter={v=>[`GH₵${v}`]}/>
              <Legend wrapperStyle={{color:C.muted,fontSize:11}}/>
              <Area type="monotone" dataKey="sales" stroke={C.accent} fill="url(#gs)" strokeWidth={2} name="Revenue"/>
              <Area type="monotone" dataKey="purchases" stroke={C.blue} fill="url(#gp)" strokeWidth={2} name="Purchases"/>
            </AreaChart>
          </ResponsiveContainer>
        </SCard>
        <SCard title="🥧 Expense Breakdown">
          <ResponsiveContainer width="100%" height={210}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={52} outerRadius={80} paddingAngle={3} dataKey="value">
                {pieData.map((_,i)=><Cell key={i} fill={PC[i%PC.length]}/>)}
              </Pie>
              <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text}} formatter={v=>[`GH₵${v}`]}/>
              <Legend wrapperStyle={{color:C.muted,fontSize:10}}/>
            </PieChart>
          </ResponsiveContainer>
        </SCard>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:16}}>
        <SCard title="📦 Stock vs Reorder Levels">
          <ResponsiveContainer width="100%" height={190}>
            <BarChart data={stockData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={C.border} horizontal={false}/>
              <XAxis type="number" stroke={C.muted} tick={{fill:C.muted,fontSize:9}}/>
              <YAxis type="category" dataKey="name" stroke={C.muted} tick={{fill:C.muted,fontSize:9}} width={48}/>
              <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text}}/>
              <Bar dataKey="qty" fill={C.cyan} name="In Stock" radius={[0,4,4,0]}/>
              <Bar dataKey="reorder" fill={C.red} name="Reorder Level" radius={[0,4,4,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </SCard>
        <SCard title="🏆 Top Customers">
          {topCust.map(c=>(
            <div key={c.id} style={{marginBottom:11}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                <span style={{color:C.text,fontSize:12}}>{c.name}</span>
                <span style={{color:C.accent,fontSize:12,fontWeight:700}}>GH₵{c.totalBought||0}</span>
              </div>
              <div style={{background:C.dim,borderRadius:4,height:5}}>
                <div style={{background:`linear-gradient(90deg,${C.accent},${C.cyan})`,borderRadius:4,height:5,width:`${((c.totalBought||0)/maxB)*100}%`}}/>
              </div>
            </div>
          ))}
        </SCard>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:16}}>
        <SCard title="⚠ Low Stock Alerts">
          {lowStock.length===0?<p style={{color:C.green,fontSize:12}}>✓ All items well stocked</p>
          :lowStock.map(i=>(
            <div key={i.id} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}>
              <span style={{color:C.text,fontSize:12}}>{i.name.split(" ")[0]}</span>
              <Badge label={`${i.qty} left`} color={C.red}/>
            </div>
          ))}
        </SCard>
        <SCard title="🧾 Recent Sales">
          {data.sales.slice(-4).reverse().map(s=>(
            <div key={s.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}>
              <div><div style={{color:C.text,fontSize:12}}>{s.customer}</div><div style={{color:C.muted,fontSize:10}}>{s.date}</div></div>
              <div style={{textAlign:"right"}}><div style={{color:C.green,fontWeight:700,fontSize:12}}>GH₵{s.total}</div><Badge label={s.status} color={s.status==="paid"?C.green:C.gold}/></div>
            </div>
          ))}
        </SCard>
        <SCard title="📊 Quick Stats">
          {[["Inventory Items",data.inventory.length,C.blue],["Customers",data.customers.length,C.purple],["Suppliers",data.suppliers.length,C.accent],["Staff",data.staff.length,C.green],["Deliveries",(data.deliveries||[]).length,C.orange]].map(([l,v,col])=>(
            <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}>
              <span style={{color:C.muted,fontSize:12}}>{l}</span>
              <span style={{color:col,fontWeight:800,fontSize:16}}>{v}</span>
            </div>
          ))}
        </SCard>
      </div>
    </div>
  );
}

/* ── INVENTORY ── */
function InventoryPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [search,setSearch]=useState("");
  const [form,setForm]=useState({name:"",category:"Grains",qty:"",unit:"bags",cost:"",price:"",reorder:""});
  const save=()=>{
    setData(d=>({...d,inventory:[...d.inventory,{id:Date.now(),...form,qty:+form.qty,cost:+form.cost,price:+form.price,reorder:+form.reorder}]}));
    setShowAdd(false);setForm({name:"",category:"Grains",qty:"",unit:"bags",cost:"",price:"",reorder:""});
  };
  const filtered=data.inventory.filter(i=>i.name.toLowerCase().includes(search.toLowerCase()));
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Inventory</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{data.inventory.length} items · Stock value: GH₵{data.inventory.reduce((a,i)=>a+i.qty*i.cost,0).toLocaleString()}</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search..." style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:8,padding:"7px 12px",color:C.text,fontSize:12,outline:"none"}}/>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",desc:"Inventory list with margins & values",action:()=>exportInventoryExcel(data.inventory)},
            {icon:"📄",label:"Export PDF",  desc:"Printable inventory report",          action:()=>exportInventoryPDF(data.inventory)},
          ]}/>
          <Btn color={C.accent} onClick={()=>setShowAdd(true)}>+ Add Item</Btn>
        </div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Item","Category","Qty","Unit","Cost","Sell Price","Margin","Reorder","Status"]}
          rows={filtered.map(i=>[
            <span style={{color:C.text,fontWeight:600}}>{i.name}</span>,
            i.category,i.qty,i.unit,`GH₵${i.cost}`,`GH₵${i.price}`,
            <span style={{color:C.green}}>{Math.round((i.price-i.cost)/i.price*100)}%</span>,
            i.reorder,<Badge label={i.qty<=i.reorder?"Low Stock":"In Stock"} color={i.qty<=i.reorder?C.red:C.green}/>
          ])}
        />
      </div>
      {showAdd&&(
        <Modal title="Add Inventory Item" onClose={()=>setShowAdd(false)}>
          <FIn label="Item Name" value={form.name} onChange={v=>setForm(f=>({...f,name:v}))}/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FSel label="Category" value={form.category} onChange={v=>setForm(f=>({...f,category:v}))} options={["Grains","Oils","Sweeteners","Condiments","Beverages","Frozen","Other"]}/>
            <FSel label="Unit" value={form.unit} onChange={v=>setForm(f=>({...f,unit:v}))} options={["bags","cans","cartons","bottles","boxes","kg","litres","pieces"]}/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
            <FIn label="Quantity" type="number" value={form.qty} onChange={v=>setForm(f=>({...f,qty:v}))}/>
            <FIn label="Cost (GH₵)" type="number" value={form.cost} onChange={v=>setForm(f=>({...f,cost:v}))}/>
            <FIn label="Sell Price" type="number" value={form.price} onChange={v=>setForm(f=>({...f,price:v}))}/>
          </div>
          <FIn label="Reorder Level" type="number" value={form.reorder} onChange={v=>setForm(f=>({...f,reorder:v}))}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.accent} onClick={save}>Save Item</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── SALES ── */
function SalesPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({customer:"",date:new Date().toISOString().slice(0,10),items:[{name:"",qty:1,price:0}],status:"unpaid"});
  const upd=(i,f2,v)=>setForm(f=>{const items=[...f.items];items[i]={...items[i],[f2]:f2==="qty"||f2==="price"?+v:v};if(f2==="name"){const inv=data.inventory.find(p=>p.name===v);if(inv)items[i].price=inv.price;}return{...f,items};});
  const total=form.items.reduce((s,i)=>s+i.qty*i.price,0);
  const save=()=>{setData(d=>({...d,sales:[...d.sales,{id:1000+d.sales.length+1,...form,total}]}));setShowAdd(false);setForm({customer:"",date:new Date().toISOString().slice(0,10),items:[{name:"",qty:1,price:0}],status:"unpaid"});};
  const paid=data.sales.filter(s=>s.status==="paid").reduce((a,s)=>a+s.total,0);
  const unpaid=data.sales.filter(s=>s.status==="unpaid").reduce((a,s)=>a+s.total,0);
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Sales & Invoices</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{data.sales.length} transactions</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",    desc:"Sales summary + line-item detail",action:()=>exportSalesExcel(data.sales)},
            {icon:"📄",label:"Export PDF Report",desc:"Printable sales report",          action:()=>exportSalesPDF(data.sales)},
          ]}/>
          <Btn color={C.accent} onClick={()=>setShowAdd(true)}>+ New Sale</Btn>
        </div>
      </div>
      <div style={{display:"flex",gap:13,marginBottom:18}}>
        <KCard label="Total Revenue" value={`GH₵${(paid+unpaid).toLocaleString()}`} color={C.green} icon="◈"/>
        <KCard label="Collected"     value={`GH₵${paid.toLocaleString()}`}           color={C.accent} icon="✓"/>
        <KCard label="Outstanding"   value={`GH₵${unpaid.toLocaleString()}`}         color={C.gold}   icon="⏳"/>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Invoice #","Date","Customer","Items","Total","Status","PDF"]}
          rows={data.sales.map(s=>[
            <span style={{color:C.accent,fontWeight:700}}>#{s.id}</span>,
            s.date,s.customer,`${s.items.length} item(s)`,
            <span style={{color:C.green,fontWeight:700}}>GH₵{s.total}</span>,
            <Badge label={s.status} color={s.status==="paid"?C.green:C.gold}/>,
            <button onClick={()=>exportInvoicePDF(s)} title="Print Invoice" style={{background:"none",border:`1px solid ${C.muted}`,borderRadius:6,color:C.muted,padding:"3px 8px",cursor:"pointer",fontSize:11}}>🖨 Invoice</button>
          ])}
        />
      </div>
      {showAdd&&(
        <Modal title="New Sale / Invoice" onClose={()=>setShowAdd(false)} wide>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FSel label="Customer" value={form.customer} onChange={v=>setForm(f=>({...f,customer:v}))} options={data.customers.map(c=>c.name)}/>
            <FIn label="Date" type="date" value={form.date} onChange={v=>setForm(f=>({...f,date:v}))}/>
          </div>
          <div style={{marginBottom:12}}>
            <label style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:1}}>Line Items</label>
            {form.items.map((item,i)=>(
              <div key={i} style={{display:"grid",gridTemplateColumns:"3fr 1fr 1fr",gap:7,marginTop:7}}>
                <select value={item.name} onChange={e=>upd(i,"name",e.target.value)} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:7,padding:"7px 10px",color:C.text,fontSize:12}}>
                  <option value="">Select item</option>{data.inventory.map(p=><option key={p.id}>{p.name}</option>)}
                </select>
                <input type="number" placeholder="Qty" value={item.qty} onChange={e=>upd(i,"qty",e.target.value)} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:7,padding:"7px 10px",color:C.text,fontSize:12}}/>
                <input type="number" placeholder="Price" value={item.price} onChange={e=>upd(i,"price",e.target.value)} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:7,padding:"7px 10px",color:C.text,fontSize:12}}/>
              </div>
            ))}
            <button onClick={()=>setForm(f=>({...f,items:[...f.items,{name:"",qty:1,price:0}]}))} style={{background:"none",border:`1px dashed ${C.border}`,color:C.muted,borderRadius:7,padding:"7px",marginTop:7,cursor:"pointer",width:"100%",fontSize:11}}>+ Add Line</button>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0",borderTop:`1px solid ${C.border}`,marginBottom:12}}>
            <span style={{color:C.muted}}>Total</span><span style={{color:C.green,fontWeight:800,fontSize:20}}>GH₵{total}</span>
          </div>
          <FSel label="Status" value={form.status} onChange={v=>setForm(f=>({...f,status:v}))} options={["paid","unpaid"]}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.accent} onClick={save}>Save Invoice</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── PURCHASES ── */
function PurchasesPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({supplier:"",date:new Date().toISOString().slice(0,10),items:[{name:"",qty:1,cost:0}],status:"unpaid"});
  const upd=(i,f2,v)=>setForm(f=>{const items=[...f.items];items[i]={...items[i],[f2]:f2==="qty"||f2==="cost"?+v:v};return{...f,items};});
  const total=form.items.reduce((s,i)=>s+i.qty*i.cost,0);
  const save=()=>{setData(d=>({...d,purchases:[...d.purchases,{id:2000+d.purchases.length+1,...form,total}]}));setShowAdd(false);setForm({supplier:"",date:new Date().toISOString().slice(0,10),items:[{name:"",qty:1,cost:0}],status:"unpaid"});};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Purchase Orders</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{data.purchases.length} orders</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",    desc:"Orders summary + item detail",action:()=>exportPurchasesExcel(data.purchases)},
            {icon:"📄",label:"Export PDF Report",desc:"Printable purchase report",   action:()=>exportPurchasesPDF(data.purchases)},
          ]}/>
          <Btn color={C.blue} onClick={()=>setShowAdd(true)}>+ New Order</Btn>
        </div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Order #","Date","Supplier","Items","Total","Status"]}
          rows={data.purchases.map(p=>[<span style={{color:C.blue,fontWeight:700}}>#{p.id}</span>,p.date,p.supplier,`${p.items.length} item(s)`,<span style={{color:C.blue,fontWeight:700}}>GH₵{p.total}</span>,<Badge label={p.status} color={p.status==="paid"?C.green:C.gold}/>])}
        />
      </div>
      {showAdd&&(
        <Modal title="New Purchase Order" onClose={()=>setShowAdd(false)} wide>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FSel label="Supplier" value={form.supplier} onChange={v=>setForm(f=>({...f,supplier:v}))} options={data.suppliers.map(s=>s.name)}/>
            <FIn label="Date" type="date" value={form.date} onChange={v=>setForm(f=>({...f,date:v}))}/>
          </div>
          <div style={{marginBottom:12}}>
            <label style={{color:C.muted,fontSize:11,textTransform:"uppercase",letterSpacing:1}}>Items</label>
            {form.items.map((item,i)=>(
              <div key={i} style={{display:"grid",gridTemplateColumns:"3fr 1fr 1fr",gap:7,marginTop:7}}>
                <input placeholder="Item name" value={item.name} onChange={e=>upd(i,"name",e.target.value)} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:7,padding:"7px 10px",color:C.text,fontSize:12}}/>
                <input type="number" placeholder="Qty" value={item.qty} onChange={e=>upd(i,"qty",e.target.value)} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:7,padding:"7px 10px",color:C.text,fontSize:12}}/>
                <input type="number" placeholder="Cost" value={item.cost} onChange={e=>upd(i,"cost",e.target.value)} style={{background:C.surface,border:`1px solid ${C.border}`,borderRadius:7,padding:"7px 10px",color:C.text,fontSize:12}}/>
              </div>
            ))}
            <button onClick={()=>setForm(f=>({...f,items:[...f.items,{name:"",qty:1,cost:0}]}))} style={{background:"none",border:`1px dashed ${C.border}`,color:C.muted,borderRadius:7,padding:"7px",marginTop:7,cursor:"pointer",width:"100%",fontSize:11}}>+ Add Line</button>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0",borderTop:`1px solid ${C.border}`,marginBottom:12}}>
            <span style={{color:C.muted}}>Total</span><span style={{color:C.blue,fontWeight:800,fontSize:20}}>GH₵{total}</span>
          </div>
          <FSel label="Status" value={form.status} onChange={v=>setForm(f=>({...f,status:v}))} options={["paid","unpaid"]}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.blue} onClick={save}>Save Order</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── CUSTOMERS ── */
function CustomersPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({name:"",contact:"",phone:"",email:"",address:"",balance:0});
  const save=()=>{setData(d=>({...d,customers:[...d.customers,{id:Date.now(),...form,balance:+form.balance,totalBought:0}]}));setShowAdd(false);setForm({name:"",contact:"",phone:"",email:"",address:"",balance:0});};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Customers</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{data.customers.length} registered</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",desc:"Full customer list with balances",action:()=>exportCustomersExcel(data.customers)},
          ]}/>
          <Btn color={C.accent} onClick={()=>setShowAdd(true)}>+ Add Customer</Btn>
        </div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Business","Contact","Phone","Email","Location","Balance"]}
          rows={data.customers.map(c=>[<span style={{color:C.text,fontWeight:600}}>{c.name}</span>,c.contact,c.phone,c.email,c.address,<span style={{color:c.balance>0?C.red:C.green,fontWeight:700}}>GH₵{c.balance}</span>])}
        />
      </div>
      {showAdd&&(
        <Modal title="Add Customer" onClose={()=>setShowAdd(false)}>
          <FIn label="Business Name" value={form.name} onChange={v=>setForm(f=>({...f,name:v}))}/>
          <FIn label="Contact Person" value={form.contact} onChange={v=>setForm(f=>({...f,contact:v}))}/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FIn label="Phone" value={form.phone} onChange={v=>setForm(f=>({...f,phone:v}))}/>
            <FIn label="Email" value={form.email} onChange={v=>setForm(f=>({...f,email:v}))}/>
          </div>
          <FIn label="Address" value={form.address} onChange={v=>setForm(f=>({...f,address:v}))}/>
          <FIn label="Opening Balance (GH₵)" type="number" value={form.balance} onChange={v=>setForm(f=>({...f,balance:v}))}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.accent} onClick={save}>Save</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── SUPPLIERS ── */
function SuppliersPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({name:"",contact:"",phone:"",email:"",product:"",balance:0});
  const save=()=>{setData(d=>({...d,suppliers:[...d.suppliers,{id:Date.now(),...form,balance:+form.balance}]}));setShowAdd(false);setForm({name:"",contact:"",phone:"",email:"",product:"",balance:0});};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Suppliers</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{data.suppliers.length} suppliers</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",desc:"Supplier list with balances owed",action:()=>exportSuppliersExcel(data.suppliers)},
          ]}/>
          <Btn color={C.purple} onClick={()=>setShowAdd(true)}>+ Add Supplier</Btn>
        </div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Company","Contact","Phone","Email","Products","Owed"]}
          rows={data.suppliers.map(s=>[<span style={{color:C.text,fontWeight:600}}>{s.name}</span>,s.contact,s.phone,s.email,s.product,<span style={{color:s.balance>0?C.red:C.green,fontWeight:700}}>GH₵{s.balance}</span>])}
        />
      </div>
      {showAdd&&(
        <Modal title="Add Supplier" onClose={()=>setShowAdd(false)}>
          <FIn label="Company Name" value={form.name} onChange={v=>setForm(f=>({...f,name:v}))}/>
          <FIn label="Contact Person" value={form.contact} onChange={v=>setForm(f=>({...f,contact:v}))}/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FIn label="Phone" value={form.phone} onChange={v=>setForm(f=>({...f,phone:v}))}/>
            <FIn label="Email" value={form.email} onChange={v=>setForm(f=>({...f,email:v}))}/>
          </div>
          <FIn label="Products Supplied" value={form.product} onChange={v=>setForm(f=>({...f,product:v}))}/>
          <FIn label="Balance Owed (GH₵)" type="number" value={form.balance} onChange={v=>setForm(f=>({...f,balance:v}))}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.purple} onClick={save}>Save</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── EXPENSES ── */
function ExpensesPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({date:new Date().toISOString().slice(0,10),category:"Rent",description:"",amount:""});
  const save=()=>{setData(d=>({...d,expenses:[...d.expenses,{id:Date.now(),...form,amount:+form.amount}]}));setShowAdd(false);setForm({date:new Date().toISOString().slice(0,10),category:"Rent",description:"",amount:""});};
  const total=data.expenses.reduce((a,e)=>a+e.amount,0);
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Expenses</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>Total: <span style={{color:C.red}}>GH₵{total.toLocaleString()}</span></p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",desc:"Expenses + category breakdown",action:()=>exportExpensesExcel(data.expenses)},
          ]}/>
          <Btn color={C.red} onClick={()=>setShowAdd(true)}>+ Record Expense</Btn>
        </div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Date","Category","Description","Amount"]}
          rows={data.expenses.map(e=>[e.date,<Badge label={e.category} color={C.purple}/>,e.description,<span style={{color:C.red,fontWeight:700}}>GH₵{e.amount}</span>])}
        />
      </div>
      {showAdd&&(
        <Modal title="Record Expense" onClose={()=>setShowAdd(false)}>
          <FIn label="Date" type="date" value={form.date} onChange={v=>setForm(f=>({...f,date:v}))}/>
          <FSel label="Category" value={form.category} onChange={v=>setForm(f=>({...f,category:v}))} options={["Rent","Salaries","Transport","Utilities","Maintenance","Marketing","Packaging","Other"]}/>
          <FIn label="Description" value={form.description} onChange={v=>setForm(f=>({...f,description:v}))}/>
          <FIn label="Amount (GH₵)" type="number" value={form.amount} onChange={v=>setForm(f=>({...f,amount:v}))}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.red} onClick={save}>Save</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── STAFF ── */
function StaffPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({name:"",role:"Sales Rep",email:"",phone:"",status:"active",salary:""});
  const save=()=>{setData(d=>({...d,staff:[...d.staff,{id:Date.now(),...form,salary:+form.salary}]}));setShowAdd(false);setForm({name:"",role:"Sales Rep",email:"",phone:"",status:"active",salary:""});};
  const payroll=data.staff.reduce((a,s)=>a+(s.salary||0),0);
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Staff</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{data.staff.length} members · Payroll: <span style={{color:C.orange}}>GH₵{payroll.toLocaleString()}</span>/month</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",desc:"Staff list with salaries & roles",action:()=>exportStaffExcel(data.staff)},
          ]}/>
          <Btn color={C.orange} onClick={()=>setShowAdd(true)}>+ Add Staff</Btn>
        </div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Name","Role","Email","Phone","Salary","Status"]}
          rows={data.staff.map(s=>[<span style={{color:C.text,fontWeight:600}}>{s.name}</span>,<Badge label={s.role} color={C.blue}/>,s.email,s.phone,<span style={{color:C.orange}}>GH₵{s.salary||"—"}</span>,<Badge label={s.status} color={s.status==="active"?C.green:C.muted}/>])}
        />
      </div>
      {showAdd&&(
        <Modal title="Add Staff" onClose={()=>setShowAdd(false)}>
          <FIn label="Full Name" value={form.name} onChange={v=>setForm(f=>({...f,name:v}))}/>
          <FSel label="Role" value={form.role} onChange={v=>setForm(f=>({...f,role:v}))} options={["Manager","Sales Rep","Accountant","Driver","Warehouse Staff","Cleaner","Other"]}/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FIn label="Email" value={form.email} onChange={v=>setForm(f=>({...f,email:v}))}/>
            <FIn label="Phone" value={form.phone} onChange={v=>setForm(f=>({...f,phone:v}))}/>
          </div>
          <FIn label="Monthly Salary (GH₵)" type="number" value={form.salary} onChange={v=>setForm(f=>({...f,salary:v}))}/>
          <FSel label="Status" value={form.status} onChange={v=>setForm(f=>({...f,status:v}))} options={["active","inactive"]}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.orange} onClick={save}>Save</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── DELIVERIES ── */
function DeliveryPage({data,setData}){
  const [showAdd,setShowAdd]=useState(false);
  const [form,setForm]=useState({date:new Date().toISOString().slice(0,10),customer:"",invoice:"",driver:"",address:"",status:"pending"});
  const save=()=>{setData(d=>({...d,deliveries:[...(d.deliveries||[]),{id:3000+(d.deliveries||[]).length+1,...form}]}));setShowAdd(false);setForm({date:new Date().toISOString().slice(0,10),customer:"",invoice:"",driver:"",address:"",status:"pending"});};
  const dels=data.deliveries||[];
  const updateStatus=(id,status)=>setData(d=>({...d,deliveries:d.deliveries.map(x=>x.id===id?{...x,status}:x)}));
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Delivery Tracker</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>{dels.filter(d=>d.status==="pending").length} pending</p></div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <ExportMenu options={[
            {icon:"📊",label:"Export Excel",desc:"Delivery log with status & drivers",action:()=>exportDeliveriesExcel(data.deliveries)},
          ]}/>
          <Btn color={C.cyan} onClick={()=>setShowAdd(true)}>+ New Delivery</Btn>
        </div>
      </div>
      <div style={{display:"flex",gap:13,marginBottom:18}}>
        <KCard label="Total" value={dels.length} color={C.cyan} icon="🚚"/>
        <KCard label="Pending" value={dels.filter(d=>d.status==="pending").length} color={C.gold} icon="⏳"/>
        <KCard label="Delivered" value={dels.filter(d=>d.status==="delivered").length} color={C.green} icon="✓"/>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["ID","Date","Customer","Invoice","Driver","Address","Status","Action"]}
          rows={dels.map(d=>[
            <span style={{color:C.cyan,fontWeight:700}}>#{d.id}</span>,
            d.date,d.customer,d.invoice?`#${d.invoice}`:"—",d.driver,d.address,
            <Badge label={d.status} color={d.status==="delivered"?C.green:d.status==="in-transit"?C.blue:C.gold}/>,
            d.status!=="delivered"?<Btn small color={C.green} onClick={()=>updateStatus(d.id,"delivered")}>✓ Delivered</Btn>:<span style={{color:C.muted,fontSize:11}}>Done</span>
          ])}
        />
      </div>
      {showAdd&&(
        <Modal title="New Delivery" onClose={()=>setShowAdd(false)}>
          <FIn label="Date" type="date" value={form.date} onChange={v=>setForm(f=>({...f,date:v}))}/>
          <FSel label="Customer" value={form.customer} onChange={v=>setForm(f=>({...f,customer:v}))} options={data.customers.map(c=>c.name)}/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <FIn label="Invoice # (optional)" value={form.invoice} onChange={v=>setForm(f=>({...f,invoice:v}))}/>
            <FSel label="Driver" value={form.driver} onChange={v=>setForm(f=>({...f,driver:v}))} options={data.staff.map(s=>s.name)}/>
          </div>
          <FIn label="Delivery Address" value={form.address} onChange={v=>setForm(f=>({...f,address:v}))}/>
          <FSel label="Status" value={form.status} onChange={v=>setForm(f=>({...f,status:v}))} options={["pending","in-transit","delivered","failed"]}/>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}><Btn outline color={C.muted} onClick={()=>setShowAdd(false)}>Cancel</Btn><Btn color={C.cyan} onClick={save}>Save Delivery</Btn></div>
        </Modal>
      )}
    </div>
  );
}

/* ── PRICE LIST ── */
function PriceListPage({data,setData}){
  const [editId,setEditId]=useState(null);
  const [editPrice,setEditPrice]=useState("");
  const saveEdit=id=>{setData(d=>({...d,inventory:d.inventory.map(i=>i.id===id?{...i,price:+editPrice}:i)}));setEditId(null);};
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Price List Manager</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>Review and update selling prices</p></div>
        <ExportMenu options={[
          {icon:"📊",label:"Export Price List Excel",desc:"All products with margins",action:()=>exportInventoryExcel(data.inventory)},
          {icon:"📄",label:"Export Price List PDF",  desc:"Printable price sheet",   action:()=>exportInventoryPDF(data.inventory)},
        ]}/>
      </div>
      <div style={{background:C.gold+"12",border:`1px solid ${C.gold}30`,borderRadius:8,padding:"9px 13px",color:C.gold,fontSize:12,marginBottom:16}}>💡 Keep profit margins above 15–20% above cost for a healthy business.</div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,overflow:"hidden"}}>
        <DTable headers={["Product","Category","Unit","Cost Price","Selling Price","Margin","Action"]}
          rows={data.inventory.map(i=>[
            <span style={{color:C.text,fontWeight:600}}>{i.name}</span>,i.category,i.unit,
            <span style={{color:C.muted}}>GH₵{i.cost}</span>,
            editId===i.id?<input type="number" value={editPrice} onChange={e=>setEditPrice(e.target.value)} style={{background:C.surface,border:`1px solid ${C.accent}`,borderRadius:6,padding:"3px 7px",color:C.text,fontSize:12,width:75}}/>:<span style={{color:C.accent,fontWeight:700}}>GH₵{i.price}</span>,
            <span style={{color:((i.price-i.cost)/i.price*100)>=15?C.green:C.red,fontWeight:700}}>{Math.round((i.price-i.cost)/i.price*100)}%</span>,
            editId===i.id?<span style={{display:"flex",gap:5}}><Btn small color={C.green} onClick={()=>saveEdit(i.id)}>Save</Btn><Btn small outline color={C.muted} onClick={()=>setEditId(null)}>✕</Btn></span>:<Btn small outline color={C.accent} onClick={()=>{setEditId(i.id);setEditPrice(i.price);}}>Edit</Btn>
          ])}
        />
      </div>
    </div>
  );
}

/* ── DEBT TRACKER ── */
function DebtPage({data,setData}){
  const cDebts=data.customers.filter(c=>c.balance>0);
  const sDebts=data.suppliers.filter(s=>s.balance>0);
  const owed=cDebts.reduce((a,c)=>a+c.balance,0);
  const owing=sDebts.reduce((a,s)=>a+s.balance,0);
  const markPaid=(type,id)=>{
    if(type==="c")setData(d=>({...d,customers:d.customers.map(c=>c.id===id?{...c,balance:0}:c)}));
    else setData(d=>({...d,suppliers:d.suppliers.map(s=>s.id===id?{...s,balance:0}:s)}));
  };
  return(
    <div>
      <div style={{marginBottom:20}}><h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Debt Tracker</h2><p style={{color:C.muted,fontSize:12,marginTop:3}}>Monitor all outstanding balances</p></div>
      <div style={{display:"flex",gap:13,marginBottom:20}}>
        <KCard label="Customers Owe You" value={`GH₵${owed.toLocaleString()}`} color={C.green} icon="⬆" sub={`${cDebts.length} customers`}/>
        <KCard label="You Owe Suppliers" value={`GH₵${owing.toLocaleString()}`} color={C.red} icon="⬇" sub={`${sDebts.length} suppliers`}/>
        <KCard label="Net Position" value={`GH₵${(owed-owing).toLocaleString()}`} color={owed>=owing?C.accent:C.red} icon="="/>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18}}>
        <SCard title="💰 Customers with Unpaid Balances">
          {cDebts.length===0?<p style={{color:C.green,fontSize:12}}>✓ No outstanding customer debts</p>
          :cDebts.map(c=>(
            <div key={c.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:`1px solid ${C.border}18`}}>
              <div><div style={{color:C.text,fontWeight:600,fontSize:13}}>{c.name}</div><div style={{color:C.muted,fontSize:11}}>{c.phone}</div></div>
              <div style={{display:"flex",alignItems:"center",gap:9}}><span style={{color:C.gold,fontWeight:800}}>GH₵{c.balance}</span><Btn small color={C.green} onClick={()=>markPaid("c",c.id)}>Mark Paid</Btn></div>
            </div>
          ))}
        </SCard>
        <SCard title="🔴 Suppliers You Owe">
          {sDebts.length===0?<p style={{color:C.green,fontSize:12}}>✓ No outstanding supplier debts</p>
          :sDebts.map(s=>(
            <div key={s.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:`1px solid ${C.border}18`}}>
              <div><div style={{color:C.text,fontWeight:600,fontSize:13}}>{s.name}</div><div style={{color:C.muted,fontSize:11}}>{s.phone}</div></div>
              <div style={{display:"flex",alignItems:"center",gap:9}}><span style={{color:C.red,fontWeight:800}}>GH₵{s.balance}</span><Btn small color={C.green} onClick={()=>markPaid("s",s.id)}>Mark Paid</Btn></div>
            </div>
          ))}
        </SCard>
      </div>
    </div>
  );
}

/* ── REPORTS ── */
function ReportsPage({data}){
  const totalSales=data.sales.reduce((a,s)=>a+s.total,0);
  const paidSales=data.sales.filter(s=>s.status==="paid").reduce((a,s)=>a+s.total,0);
  const unpaidSales=data.sales.filter(s=>s.status==="unpaid").reduce((a,s)=>a+s.total,0);
  const totalPurch=data.purchases.reduce((a,p)=>a+p.total,0);
  const totalExp=data.expenses.reduce((a,e)=>a+e.amount,0);
  const grossProfit=totalSales-totalPurch;
  const netProfit=grossProfit-totalExp;
  const MK=["2025-09","2025-10","2025-11","2025-12","2026-01","2026-02","2026-03"];
  const ML=["Sep","Oct","Nov","Dec","Jan","Feb","Mar"];
  const profitTrend=MK.map((mk,i)=>{
    const rev=data.sales.filter(s=>s.date.startsWith(mk)).reduce((a,s)=>a+s.total,0);
    const cost=data.purchases.filter(p=>p.date.startsWith(mk)).reduce((a,p)=>a+p.total,0);
    const exp=data.expenses.filter(e=>e.date.startsWith(mk)).reduce((a,e)=>a+e.amount,0);
    return{month:ML[i],revenue:rev,cost,profit:rev-cost-exp};
  });
  const expByCat=data.expenses.reduce((acc,e)=>{acc[e.category]=(acc[e.category]||0)+e.amount;return acc;},{});
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
        <div>
          <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,margin:0}}>Reports & Analytics</h2>
          <p style={{color:C.muted,fontSize:12,marginTop:3}}>Financial summary for {SYSTEM_NAME}</p>
        </div>
        <ExportMenu options={[
          {icon:"📊",label:"Export Full Excel",desc:"All modules in one workbook",      action:()=>exportFullWorkbook(data)},
          {icon:"📄",label:"Export P&L PDF",   desc:"Financial report ready to print",  action:()=>exportReportsPDF(data)},
        ]}/>
      </div>
      <div style={{display:"flex",gap:13,flexWrap:"wrap",marginBottom:20}}>
        <KCard label="Gross Profit" value={`GH₵${grossProfit.toLocaleString()}`} color={grossProfit>=0?C.green:C.red} icon="◈"/>
        <KCard label="Net Profit" value={`GH₵${netProfit.toLocaleString()}`} color={netProfit>=0?C.accent:C.red} icon="◎"/>
        <KCard label="Inventory Value" value={`GH₵${data.inventory.reduce((a,i)=>a+i.qty*i.cost,0).toLocaleString()}`} color={C.blue} icon="◫"/>
        <KCard label="Receivables" value={`GH₵${unpaidSales.toLocaleString()}`} color={C.gold} icon="◷"/>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"2fr 1fr",gap:16,marginBottom:16}}>
        <SCard title="📊 Monthly Profit Trend">
          <ResponsiveContainer width="100%" height={210}>
            <BarChart data={profitTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
              <XAxis dataKey="month" stroke={C.muted} tick={{fill:C.muted,fontSize:10}}/>
              <YAxis stroke={C.muted} tick={{fill:C.muted,fontSize:10}} tickFormatter={v=>`₵${v}`}/>
              <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text}} formatter={v=>[`GH₵${v}`]}/>
              <Legend wrapperStyle={{color:C.muted,fontSize:10}}/>
              <Bar dataKey="revenue" fill={C.green} name="Revenue" radius={[3,3,0,0]}/>
              <Bar dataKey="cost" fill={C.blue} name="Purchases" radius={[3,3,0,0]}/>
              <Bar dataKey="profit" fill={C.accent} name="Profit" radius={[3,3,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </SCard>
        <SCard title="💼 P&L Summary">
          {[["Total Revenue",`GH₵${totalSales.toLocaleString()}`,C.green],["Paid Invoices",`GH₵${paidSales.toLocaleString()}`,C.green],["Unpaid",`GH₵${unpaidSales.toLocaleString()}`,C.gold],["Cost of Goods",`GH₵${totalPurch.toLocaleString()}`,C.red],["Expenses",`GH₵${totalExp.toLocaleString()}`,C.red],["Gross Profit",`GH₵${grossProfit.toLocaleString()}`,C.blue],["Net Profit",`GH₵${netProfit.toLocaleString()}`,netProfit>=0?C.accent:C.red]].map(([l,v,col])=>(
            <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}>
              <span style={{color:C.muted,fontSize:12}}>{l}</span><span style={{color:col,fontWeight:700,fontSize:12}}>{v}</span>
            </div>
          ))}
        </SCard>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <SCard title="📦 Expense by Category">
          {Object.entries(expByCat).map(([cat,amt])=>{const pct=Math.round(amt/totalExp*100);return(
            <div key={cat} style={{marginBottom:11}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{color:C.text,fontSize:12}}>{cat}</span><span style={{color:C.red,fontWeight:700,fontSize:12}}>GH₵{amt} ({pct}%)</span></div>
              <div style={{background:C.dim,borderRadius:3,height:5}}><div style={{background:C.red,borderRadius:3,height:5,width:`${pct}%`}}/></div>
            </div>
          );})}
        </SCard>
        <SCard title="🏆 Top Products">
          {data.inventory.map(item=>{const sold=data.sales.flatMap(s=>s.items).filter(i=>i.name===item.name).reduce((a,i)=>a+i.qty,0);return sold>0?(
            <div key={item.id} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}>
              <span style={{color:C.text,fontSize:12}}>{item.name.split(" ")[0]}</span>
              <span style={{color:C.accent,fontWeight:700,fontSize:12}}>{sold} units · GH₵{(sold*item.price).toLocaleString()}</span>
            </div>
          ):null;})}
        </SCard>
      </div>
    </div>
  );
}

/* ── SETTINGS ── */
function SettingsPage({subscription,onLogout}){
  const [biz,setBiz]=useState({name:"Makin Limited",email:"info@makin.com",phone:"0596363851",address:"Accra, Ghana",currency:"GH₵"});
  const [saved,setSaved]=useState(false);
  const save=()=>{setSaved(true);setTimeout(()=>setSaved(false),2500);};
  return(
    <div style={{maxWidth:680}}>
      <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,marginBottom:4}}>Settings</h2>
      <p style={{color:C.muted,fontSize:12,marginBottom:24}}>Business profile & preferences</p>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26,marginBottom:18}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:18}}>Business Profile</h3>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
          <FIn label="Business Name" value={biz.name} onChange={v=>setBiz(b=>({...b,name:v}))}/>
          <FIn label="Email" value={biz.email} onChange={v=>setBiz(b=>({...b,email:v}))}/>
          <FIn label="Phone" value={biz.phone} onChange={v=>setBiz(b=>({...b,phone:v}))}/>
          <FIn label="Address" value={biz.address} onChange={v=>setBiz(b=>({...b,address:v}))}/>
        </div>
        <FSel label="Currency" value={biz.currency} onChange={v=>setBiz(b=>({...b,currency:v}))} options={["GH₵","USD","EUR","NGN","XOF"]}/>
        <div style={{display:"flex",gap:12,alignItems:"center"}}><Btn color={C.accent} onClick={save}>Save Changes</Btn>{saved&&<span style={{color:C.green,fontSize:12}}>✓ Saved</span>}</div>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26,marginBottom:18}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:14}}>Subscription</h3>
        {subscription?(<div>{[["Business",subscription.bizName],["Plan",subscription.plan.toUpperCase()],["Activated",new Date(subscription.activatedAt).toLocaleDateString()],["Expires",new Date(subscription.expiresAt).toLocaleDateString()],["Ref",subscription.ref]].map(([k,v])=>(
          <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}><span style={{color:C.muted,fontSize:12}}>{k}</span><span style={{color:C.text,fontWeight:600,fontSize:12}}>{v}</span></div>
        ))}<div style={{marginTop:10}}><Badge label="Active" color={C.green}/></div></div>):<p style={{color:C.muted}}>No active subscription.</p>}
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:10}}>Danger Zone</h3>
        <p style={{color:C.muted,fontSize:12,marginBottom:14}}>Log out and return to the subscription screen.</p>
        <Btn color={C.red} onClick={onLogout}>Logout / Switch Business</Btn>
      </div>
    </div>
  );
}

/* ── SECURITY ── */
function SecurityPage(){
  const [pin,setPin]=useState({current:"",newPin:"",confirm:""});
  const [msg,setMsg]=useState(null);
  const change=()=>{
    if(pin.newPin.length<4){setMsg({t:"err",m:"PIN must be at least 4 digits."});return;}
    if(pin.newPin!==pin.confirm){setMsg({t:"err",m:"PINs do not match."});return;}
    setMsg({t:"ok",m:"✓ PIN updated."});setPin({current:"",newPin:"",confirm:""});setTimeout(()=>setMsg(null),3000);
  };
  return(
    <div style={{maxWidth:680}}>
      <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,marginBottom:4}}>Security</h2>
      <p style={{color:C.muted,fontSize:12,marginBottom:24}}>Access control & security settings</p>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26,marginBottom:18}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:18}}>Change PIN</h3>
        <FIn label="Current PIN" type="password" value={pin.current} onChange={v=>setPin(p=>({...p,current:v}))}/>
        <FIn label="New PIN" type="password" value={pin.newPin} onChange={v=>setPin(p=>({...p,newPin:v}))}/>
        <FIn label="Confirm New PIN" type="password" value={pin.confirm} onChange={v=>setPin(p=>({...p,confirm:v}))}/>
        {msg&&<p style={{color:msg.t==="ok"?C.green:C.red,fontSize:12,marginBottom:10}}>{msg.m}</p>}
        <Btn color={C.blue} onClick={change}>Update PIN</Btn>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:14}}>Security Tips</h3>
        {[["Strong PIN","Avoid obvious PINs like 1234."],["Log out","Always log out on shared devices."],["Daily Backup","Export backup every evening."],["Limit Access","Only share login with trusted staff."]].map(([t,d])=>(
          <div key={t} style={{display:"flex",gap:12,padding:"9px 0",borderBottom:`1px solid ${C.border}18`}}>
            <span>🔒</span><div><div style={{color:C.text,fontWeight:600,fontSize:13}}>{t}</div><div style={{color:C.muted,fontSize:12}}>{d}</div></div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── INSTRUCTIONS ── */
function InstructionsPage(){
  const sections=[
    {title:"Getting Started",icon:"🚀",steps:["Dashboard gives you a live overview of everything.","Go to Inventory first — add all products with prices and reorder levels.","Add Customers and Suppliers before recording transactions.","You're ready to record Sales, Purchases, Deliveries, and Expenses."]},
    {title:"Recording a Sale",icon:"◈",steps:["Sales & Invoices → New Sale.","Select customer and date.","Add line items — price auto-fills from Inventory.","Set Paid or Unpaid, save."]},
    {title:"Delivery Tracking",icon:"🚚",steps:["Deliveries → New Delivery after creating a sale.","Assign a driver and set status.","Click '✓ Delivered' when item arrives.","Dashboard shows pending count."]},
    {title:"Debt Tracker",icon:"💰",steps:["Debt Tracker shows all outstanding balances.","Left: customers who owe you.","Right: suppliers you owe.","Click Mark Paid to clear settled debts."]},
    {title:"Saving Data",icon:"💾",steps:["Data resets on refresh — always Export Backup before closing.","Save the .json file to Google Drive or USB.","Next session: Import Backup to restore.","Back up daily."]},
  ];
  return(
    <div style={{maxWidth:750}}>
      <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,marginBottom:4}}>How to Use</h2>
      <p style={{color:C.muted,fontSize:12,marginBottom:22}}>Step-by-step guide to every feature</p>
      {sections.map((sec,i)=>(
        <div key={i} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:22,marginBottom:12}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}><span style={{fontSize:20}}>{sec.icon}</span><h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,margin:0}}>{sec.title}</h3></div>
          {sec.steps.map((step,j)=>(
            <div key={j} style={{display:"flex",gap:10,padding:"6px 0",borderBottom:j<sec.steps.length-1?`1px solid ${C.border}18`:"none"}}>
              <div style={{width:19,height:19,borderRadius:"50%",background:C.accent+"22",border:`1px solid ${C.accent}44`,display:"flex",alignItems:"center",justifyContent:"center",color:C.accent,fontSize:9,fontWeight:800,flexShrink:0,marginTop:2}}>{j+1}</div>
              <span style={{color:C.muted,fontSize:12,lineHeight:1.6}}>{step}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

/* ── SYSTEM UPDATE ── */
function SystemUpdatePage(){
  const [checking,setChecking]=useState(false);
  const [status,setStatus]=useState(null);
  const check=()=>{setChecking(true);setTimeout(()=>{setChecking(false);setStatus("latest");},2200);};
  return(
    <div style={{maxWidth:680}}>
      <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,marginBottom:4}}>System Updates</h2>
      <p style={{color:C.muted,fontSize:12,marginBottom:22}}>Version history & update checker</p>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26,marginBottom:18}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:status?14:0}}>
          <div><div style={{color:C.text,fontWeight:700}}>{SYSTEM_NAME}</div><div style={{color:C.muted,fontSize:12}}>Version: <span style={{color:C.accent}}>v{SYSTEM_VERSION}</span></div></div>
          <Btn color={C.blue} onClick={check}>{checking?"Checking...":"Check for Updates"}</Btn>
        </div>
        {status==="latest"&&<div style={{background:C.green+"18",border:`1px solid ${C.green}44`,borderRadius:9,padding:12,color:C.green,fontSize:13}}>✓ You are on the latest version.</div>}
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:18}}>Changelog</h3>
        {[{v:"2.0.0",d:"March 2026",t:"Current",col:C.green,n:["Visual dashboard with charts","Delivery Tracker","Price List Manager","Debt Tracker","Notifications","Deep-ocean color theme","Updated MoMo: 0596363851"]},{v:"1.4.2",d:"Feb 2026",t:"Previous",col:C.muted,n:["Export/Import backup","MoMo subscription gate","Security & Instructions"]},{v:"1.0.0",d:"Jan 2026",t:"Launch",col:C.muted,n:["Initial release"]}].map((v,i)=>(
          <div key={i} style={{borderLeft:`3px solid ${v.col}`,paddingLeft:18,marginBottom:22}}>
            <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:7}}><span style={{color:v.col,fontWeight:800,fontSize:15}}>v{v.v}</span><Badge label={v.t} color={v.col}/><span style={{color:C.muted,fontSize:11}}>{v.d}</span></div>
            {v.n.map((n,j)=><div key={j} style={{color:C.muted,fontSize:12,padding:"2px 0"}}>• {n}</div>)}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── ABOUT ── */
function AboutPage(){
  return(
    <div style={{maxWidth:680}}>
      <h2 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:25,marginBottom:4}}>About</h2>
      <p style={{color:C.muted,fontSize:12,marginBottom:22}}>About this system and its publisher</p>
      <div style={{background:`linear-gradient(135deg,${C.card},${C.accent}0a)`,border:`1px solid ${C.accent}33`,borderRadius:14,padding:30,marginBottom:18,textAlign:"center"}}>
        <div style={{width:66,height:66,background:`linear-gradient(135deg,${C.accent},${C.cyan})`,borderRadius:18,display:"flex",alignItems:"center",justifyContent:"center",fontSize:34,fontFamily:"'Playfair Display',serif",fontWeight:900,color:C.bg,margin:"0 auto 14px",boxShadow:`0 0 36px ${C.accent}44`}}>M</div>
        <h3 style={{color:C.accent,fontFamily:"'Playfair Display',serif",fontSize:24,margin:0}}>{SYSTEM_NAME}</h3>
        <p style={{color:C.muted,fontSize:12,marginTop:5}}>v{SYSTEM_VERSION} · Ghana & West Africa · Provisions Business Software</p>
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26,marginBottom:18}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:14}}>Developer Details</h3>
        {[["Company","Makin Limited"],["Product",SYSTEM_NAME],["Version",SYSTEM_VERSION],["Country","Ghana"],["MoMo",OWNER_MOMO.number],["Support","support@makinlimited.com"],["Year",new Date().getFullYear().toString()]].map(([k,v])=>(
          <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${C.border}18`}}>
            <span style={{color:C.muted,fontSize:12}}>{k}</span>
            <span style={{color:k==="MoMo"?C.accent:C.text,fontWeight:k==="MoMo"?700:400,fontSize:12}}>{v}</span>
          </div>
        ))}
      </div>
      <div style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:14,padding:26}}>
        <h3 style={{color:C.text,fontFamily:"'Playfair Display',serif",fontSize:16,marginBottom:12}}>All Modules</h3>
        <div style={{display:"flex",flexWrap:"wrap",gap:7}}>
          {["Dashboard","Inventory","Sales","Purchases","Customers","Suppliers","Expenses","Staff","Deliveries","Price List","Debt Tracker","Reports","Settings","Security","Instructions","Updates"].map(m=><Badge key={m} label={m} color={C.accent}/>)}
        </div>
        <p style={{color:C.muted,fontSize:11,marginTop:14}}>© {new Date().getFullYear()} Makin Limited. All rights reserved.</p>
      </div>
    </div>
  );
}

/* ── NAV ── */
const NAV_MAIN=[
  {id:"dashboard",icon:"⬡",label:"Dashboard"},
  {id:"inventory",icon:"◫",label:"Inventory"},
  {id:"sales",icon:"◈",label:"Sales"},
  {id:"purchases",icon:"◉",label:"Purchases"},
  {id:"customers",icon:"◎",label:"Customers"},
  {id:"suppliers",icon:"◐",label:"Suppliers"},
  {id:"expenses",icon:"◑",label:"Expenses"},
  {id:"staff",icon:"◒",label:"Staff"},
  {id:"deliveries",icon:"🚚",label:"Deliveries"},
  {id:"pricelist",icon:"🏷",label:"Price List"},
  {id:"debts",icon:"💰",label:"Debt Tracker"},
  {id:"reports",icon:"◓",label:"Reports"},
];
const NAV_SYS=[
  {id:"instructions",icon:"◷",label:"How to Use"},
  {id:"settings",icon:"◧",label:"Settings"},
  {id:"security",icon:"◨",label:"Security"},
  {id:"updates",icon:"◩",label:"Updates"},
  {id:"about",icon:"◪",label:"About"},
];

/* ── AUDIT LOGGER HELPER ── */
function createAuditEntry(action, module, description, user, idCounter) {
  const now = new Date();
  return {
    id: idCounter,
    timestamp: now.toLocaleString(),
    action,
    module,
    description,
    user,
    session: "SES-" + Math.random().toString(36).slice(2,8).toUpperCase(),
  };
}

const INITIAL_AUDIT = [
  { id:1, timestamp: new Date(Date.now()-6*3600000).toLocaleString(), action:"SYSTEM",  module:"System",    description:"Makin BizSystem v2.0 started",                  user:"System",       session:"SES-BOOT01" },
  { id:2, timestamp: new Date(Date.now()-5*3600000).toLocaleString(), action:"LOGIN",   module:"System",    description:"User logged in and activated subscription",      user:"Makin Limited",session:"SES-A1B2C3" },
  { id:3, timestamp: new Date(Date.now()-4*3600000).toLocaleString(), action:"CREATE",  module:"Sales",     description:"New invoice #1007 created for Bright Stores",   user:"Makin Limited",session:"SES-A1B2C3" },
  { id:4, timestamp: new Date(Date.now()-3*3600000).toLocaleString(), action:"PAYMENT", module:"Sales",     description:"Invoice #1007 marked as paid — GH₵300",          user:"Makin Limited",session:"SES-A1B2C3" },
  { id:5, timestamp: new Date(Date.now()-2*3600000).toLocaleString(), action:"CREATE",  module:"Deliveries","description":"Delivery #3002 created for Grace Provisions",  user:"Makin Limited",session:"SES-A1B2C3" },
  { id:6, timestamp: new Date(Date.now()-1*3600000).toLocaleString(), action:"UPDATE",  module:"Inventory", description:"Stock level check triggered for Palm Oil (25L)", user:"System",       session:"SES-AUTO01" },
  { id:7, timestamp: new Date(Date.now()-30*60000).toLocaleString(),  action:"VIEW",    module:"Reports",   description:"Reports & Analytics page viewed",               user:"Makin Limited",session:"SES-A1B2C3" },
  { id:8, timestamp: new Date(Date.now()-10*60000).toLocaleString(),  action:"VIEW",    module:"Admin",     description:"Admin Dashboard accessed",                      user:"Makin Limited",session:"SES-A1B2C3" },
];

/* ── APP ── */
export default function App(){
  const [page,setPage]         = useState("dashboard");
  const [data,setData]         = useState(initialData);
  const [sub,setSub]           = useState(null);          // logged-in user object
  const [open,setOpen]         = useState(true);
  const [notifs,setNotifs]     = useState(initialData.notifications);
  const [auditLog,setAuditLog] = useState(INITIAL_AUDIT);
  const [auditCounter,setAuditCounter] = useState(INITIAL_AUDIT.length+1);
  const [subscribers,setSubscribers]   = useState([]);
  const [users,setUsers]               = useState(INITIAL_USERS);

  const addAudit=(action,module,description)=>{
    const entry=createAuditEntry(action,module,description,sub?.bizName||"System",auditCounter);
    setAuditLog(prev=>[...prev,entry]);
    setAuditCounter(c=>c+1);
  };

  const setDataWithAudit=(updater,action,module,desc)=>{
    setData(updater);
    if(action&&module&&desc) addAudit(action,module,desc);
  };

  const handleLogin=(user)=>{
    setSub(user);
    addAudit("LOGIN","System",`${user.bizName} signed in (${user.role})`);
  };

  const handleLogout=()=>{
    addAudit("SYSTEM","System",`${sub?.bizName||"User"} signed out`);
    setSub(null);
    setPage("dashboard");
  };

  if(!sub) return (
    <AuthGate
      onLogin={handleLogin}
      users={users}
      setUsers={setUsers}
      subscribers={subscribers}
      setSubscribers={setSubscribers}
    />
  );

  const NB=({item})=>(
    <button onClick={()=>{ setPage(item.id); addAudit("VIEW", item.label, `Navigated to ${item.label} page`); }} style={{width:"100%",display:"flex",alignItems:"center",gap:9,padding:open?"8px 13px":"8px 0",justifyContent:open?"flex-start":"center",background:page===item.id?C.accent+"18":"none",border:"none",borderLeft:`3px solid ${page===item.id?C.accent:"transparent"}`,borderRadius:"0 7px 7px 0",cursor:"pointer",marginBottom:2,transition:"all 0.15s"}}>
      <span style={{fontSize:14,color:page===item.id?C.accent:C.muted}}>{item.icon}</span>
      {open&&<span style={{color:page===item.id?C.accent:C.muted,fontSize:11,fontFamily:"'Barlow Condensed',sans-serif",fontWeight:600,letterSpacing:0.5}}>{item.label}</span>}
    </button>
  );

  return(
    <>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@300;400;500&display=swap');*{margin:0;padding:0;box-sizing:border-box;}body{background:${C.bg};color:${C.text};font-family:'Barlow',sans-serif;}::-webkit-scrollbar{width:4px;}::-webkit-scrollbar-track{background:${C.surface};}::-webkit-scrollbar-thumb{background:${C.border};border-radius:2px;}`}</style>
      <div style={{display:"flex",minHeight:"100vh"}}>
        <div style={{width:open?215:52,background:C.surface,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",transition:"width 0.2s",flexShrink:0}}>
          <div style={{padding:open?"22px 16px 16px":"22px 8px 16px",borderBottom:`1px solid ${C.border}`}}>
            <div style={{display:"flex",alignItems:"center",gap:9}}>
              <div style={{width:32,height:32,background:`linear-gradient(135deg,${C.accent},${C.cyan})`,borderRadius:9,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,color:C.bg,fontSize:16,flexShrink:0,fontFamily:"'Playfair Display',serif",boxShadow:`0 0 14px ${C.accent}44`}}>M</div>
              {open&&<div><div style={{color:C.accent,fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:13,lineHeight:1.1}}>Makin</div><div style={{color:C.muted,fontSize:8,textTransform:"uppercase",letterSpacing:2}}>BizSystem</div></div>}
            </div>
          </div>
          <nav style={{flex:1,padding:"10px 7px",overflowY:"auto"}}>
            {open&&<div style={{color:C.muted,fontSize:8,textTransform:"uppercase",letterSpacing:1.5,padding:"3px 13px 7px"}}>Main</div>}
            {NAV_MAIN.map(item=><NB key={item.id} item={item}/>)}
            {open&&<div style={{color:C.muted,fontSize:8,textTransform:"uppercase",letterSpacing:1.5,padding:"10px 13px 7px"}}>System</div>}
            {NAV_SYS.map(item=><NB key={item.id} item={item}/>)}
          </nav>
          <div style={{padding:"8px 7px 14px",borderTop:`1px solid ${C.border}`}}>
            <button onClick={()=>setOpen(o=>!o)} style={{width:"100%",background:"none",border:`1px solid ${C.border}`,color:C.muted,borderRadius:7,padding:"6px 0",cursor:"pointer",fontSize:12}}>{open?"◂":"▸"}</button>
          </div>
        </div>
        <div style={{flex:1,display:"flex",flexDirection:"column",maxHeight:"100vh",overflow:"hidden"}}>
          <TopBar data={data} setData={setData} notifications={notifs} setNotifications={setNotifs} bizName={sub.bizName} role={sub.role} onLogout={handleLogout}/>
          <div style={{flex:1,padding:26,overflowY:"auto"}}>
            {page==="dashboard"&&<Dashboard data={data}/>}
            {page==="inventory"&&<InventoryPage data={data} setData={setData}/>}
            {page==="sales"&&<SalesPage data={data} setData={setData}/>}
            {page==="purchases"&&<PurchasesPage data={data} setData={setData}/>}
            {page==="customers"&&<CustomersPage data={data} setData={setData}/>}
            {page==="suppliers"&&<SuppliersPage data={data} setData={setData}/>}
            {page==="expenses"&&<ExpensesPage data={data} setData={setData}/>}
            {page==="staff"&&<StaffPage data={data} setData={setData}/>}
            {page==="deliveries"&&<DeliveryPage data={data} setData={setData}/>}
            {page==="pricelist"&&<PriceListPage data={data} setData={setData}/>}
            {page==="debts"&&<DebtPage data={data} setData={setData}/>}
            {page==="reports"&&<ReportsPage data={data}/>}
            {page==="settings"&&<SettingsPage subscription={sub} onLogout={handleLogout}/>}
            {page==="security"&&<SecurityPage/>}
            {page==="instructions"&&<InstructionsPage/>}
            {page==="updates"&&<SystemUpdatePage/>}
            {page==="about"&&<AboutPage/>}
            {page==="admin"&&<AdminDashboard data={data} subscription={sub} auditLog={auditLog} subscribers={subscribers} users={users} setUsers={setUsers} currentUser={sub}/>}
            {page==="audit"&&<AuditTrailPage auditLog={auditLog} clearLog={()=>{ setAuditLog([]); setAuditCounter(1); }}/>}
          </div>
        </div>
      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════════
   ADMIN DASHBOARD
══════════════════════════════════════════════════════════════════ */

function UserRoleRow({ user, currentUser, onChangeRole, rowBg }) {
  const [editing, setEditing] = useState(false);
  const [selectedRole, setSelectedRole] = useState(user.role);
  const role = ROLES.find(r=>r.id===user.role)||ROLES[1];
  const isOwner = user.isOwner;
  const isSelf  = user.id===currentUser.id;
  const expired = user.expiresAt && new Date(user.expiresAt)<new Date();

  const save=()=>{
    onChangeRole(selectedRole);
    setEditing(false);
  };

  return(
    <tr style={{ borderBottom:`1px solid ${C.border}15`, background:rowBg }}>
      <td style={{ padding:"10px 14px" }}>
        <div style={{ color:C.text, fontWeight:600, fontSize:12 }}>{user.bizName}</div>
        {isOwner&&<span style={{ background:C.purple+"22", color:C.purple, fontSize:9, borderRadius:4, padding:"1px 6px", fontWeight:700 }}>SYSTEM OWNER</span>}
        {isSelf&&!isOwner&&<span style={{ background:C.accent+"22", color:C.accent, fontSize:9, borderRadius:4, padding:"1px 6px", fontWeight:700 }}>YOU</span>}
      </td>
      <td style={{ padding:"10px 14px", color:C.muted, fontSize:12 }}>{user.email}</td>
      <td style={{ padding:"10px 14px", color:C.muted, fontSize:12 }}>{user.phone}</td>
      <td style={{ padding:"10px 14px" }}>
        {editing && !isOwner && !isSelf ? (
          <select value={selectedRole} onChange={e=>setSelectedRole(e.target.value)}
            style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, padding:"5px 8px", fontSize:12, outline:"none" }}>
            {ROLES.filter(r=>r.id!=="owner").map(r=>(
              <option key={r.id} value={r.id}>{r.label}</option>
            ))}
          </select>
        ) : (
          <Badge label={role.label} color={role.color}/>
        )}
      </td>
      <td style={{ padding:"10px 14px" }}>
        {user.plan ? <Badge label={user.plan.toUpperCase()} color={C.blue}/> : <span style={{color:C.muted,fontSize:11}}>No plan</span>}
      </td>
      <td style={{ padding:"10px 14px", color:expired?C.red:C.muted, fontSize:11 }}>
        {user.expiresAt ? new Date(user.expiresAt).toLocaleDateString() : "—"}
        {expired&&<div style={{color:C.red,fontSize:9,fontWeight:700}}>EXPIRED</div>}
      </td>
      <td style={{ padding:"10px 14px" }}>
        {isOwner||isSelf ? (
          <span style={{ color:C.muted, fontSize:11 }}>—</span>
        ) : editing ? (
          <div style={{ display:"flex", gap:6 }}>
            <button onClick={save}     style={{ background:C.accent+"22", border:`1px solid ${C.accent}44`, borderRadius:6, color:C.accent, padding:"4px 10px", cursor:"pointer", fontSize:11, fontWeight:700 }}>Save</button>
            <button onClick={()=>setEditing(false)} style={{ background:"none", border:`1px solid ${C.border}`, borderRadius:6, color:C.muted, padding:"4px 10px", cursor:"pointer", fontSize:11 }}>Cancel</button>
          </div>
        ) : (
          <button onClick={()=>setEditing(true)} style={{ background:C.dim, border:`1px solid ${C.border}`, borderRadius:6, color:C.text, padding:"4px 10px", cursor:"pointer", fontSize:11, fontWeight:600 }}>✏ Change Role</button>
        )}
      </td>
    </tr>
  );
}
const ADMIN_PIN = "1234"; // default admin pin

function AdminDashboard({ data, subscription, auditLog, subscribers, users=[], setUsers=()=>{}, currentUser={} }) {
  const [pinEntered, setPinEntered] = useState("");
  const [unlocked, setUnlocked]     = useState(false);
  const [pinError, setPinError]     = useState("");
  const [tab, setTab]               = useState("overview");

  const unlock = () => {
    if (pinEntered === ADMIN_PIN) { setUnlocked(true); setPinError(""); }
    else { setPinError("Incorrect admin PIN. Default is 1234."); }
  };

  if (!unlocked) return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:"60vh" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:40, maxWidth:380, width:"100%", textAlign:"center" }}>
        <div style={{ fontSize:40, marginBottom:16 }}>🛡️</div>
        <h2 style={{ color:C.accent, fontFamily:"'Playfair Display',serif", fontSize:22, marginBottom:6 }}>Admin Access</h2>
        <p style={{ color:C.muted, fontSize:13, marginBottom:24 }}>This area is restricted to administrators only. Enter your admin PIN to continue.</p>
        <input
          type="password" value={pinEntered} onChange={e=>setPinEntered(e.target.value)}
          onKeyDown={e=>e.key==="Enter"&&unlock()}
          placeholder="Enter Admin PIN"
          style={{ width:"100%", background:C.surface, border:`1px solid ${pinError?C.red:C.border}`, borderRadius:9, padding:"12px 16px", color:C.text, fontSize:16, outline:"none", textAlign:"center", letterSpacing:6, marginBottom:14, boxSizing:"border-box" }}
        />
        {pinError && <p style={{ color:C.red, fontSize:12, marginBottom:12 }}>{pinError}</p>}
        <Btn full color={C.accent} onClick={unlock}>Unlock Admin Panel</Btn>
        <p style={{ color:C.muted, fontSize:11, marginTop:14 }}>Default PIN: 1234 · Change in Security settings</p>
      </div>
    </div>
  );

  // ── Computed metrics ──
  const totalRevenue   = data.sales.reduce((a,s)=>a+s.total,0);
  const totalPurchases = data.purchases.reduce((a,p)=>a+p.total,0);
  const totalExpenses  = data.expenses.reduce((a,e)=>a+e.amount,0);
  const netProfit      = totalRevenue - totalPurchases - totalExpenses;
  const unpaidSales    = data.sales.filter(s=>s.status==="unpaid").reduce((a,s)=>a+s.total,0);
  const unpaidPurch    = data.purchases.filter(p=>p.status==="unpaid").reduce((a,p)=>a+p.total,0);
  const lowStockCount  = data.inventory.filter(i=>i.qty<=i.reorder).length;
  const stockValue     = data.inventory.reduce((a,i)=>a+i.qty*i.cost,0);
  const payroll        = data.staff.reduce((a,s)=>a+(s.salary||0),0);
  const activeStaff    = data.staff.filter(s=>s.status==="active").length;
  const pendingDels    = (data.deliveries||[]).filter(d=>d.status==="pending").length;
  const totalCustDebt  = data.customers.filter(c=>c.balance>0).reduce((a,c)=>a+c.balance,0);
  const totalSupDebt   = data.suppliers.filter(s=>s.balance>0).reduce((a,s)=>a+s.balance,0);

  const MONTHS = ["Sep","Oct","Nov","Dec","Jan","Feb","Mar"];
  const MK     = ["2025-09","2025-10","2025-11","2025-12","2026-01","2026-02","2026-03"];
  const revenueChart = MK.map((mk,i)=>({
    month: MONTHS[i],
    revenue:  data.sales.filter(s=>s.date.startsWith(mk)).reduce((a,s)=>a+s.total,0),
    expenses: data.expenses.filter(e=>e.date.startsWith(mk)).reduce((a,e)=>a+e.amount,0),
    profit:   data.sales.filter(s=>s.date.startsWith(mk)).reduce((a,s)=>a+s.total,0)
              - data.purchases.filter(p=>p.date.startsWith(mk)).reduce((a,p)=>a+p.total,0)
              - data.expenses.filter(e=>e.date.startsWith(mk)).reduce((a,e)=>a+e.amount,0),
  }));

  const tabs = [
    { id:"overview",     label:"Overview"        },
    { id:"financial",    label:"Financials"       },
    { id:"operations",   label:"Operations"       },
    { id:"subscribers",  label:"Subscribers"      },
    { id:"users",        label:"Users & Roles"    },
    { id:"system",       label:"System Health"    },
  ];

  return (
    <div>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:22 }}>
        <div>
          <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:4 }}>
            <span style={{ fontSize:20 }}>🛡️</span>
            <h2 style={{ color:C.accent, fontFamily:"'Playfair Display',serif", fontSize:26, margin:0 }}>Admin Dashboard</h2>
            <Badge label="Admin" color={C.purple} />
          </div>
          <p style={{ color:C.muted, fontSize:12 }}>Full system overview · {new Date().toLocaleString()}</p>
        </div>
        <Btn small outline color={C.red} onClick={()=>setUnlocked(false)}>🔒 Lock</Btn>
      </div>

      {/* Tab Nav */}
      <div style={{ display:"flex", gap:6, marginBottom:22, flexWrap:"wrap" }}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{ background:tab===t.id?C.accent:"none", color:tab===t.id?C.bg:C.muted, border:`1px solid ${tab===t.id?C.accent:C.border}`, borderRadius:8, padding:"7px 16px", cursor:"pointer", fontSize:12, fontWeight:700, fontFamily:"'Barlow Condensed',sans-serif", letterSpacing:0.5, transition:"all 0.15s" }}>{t.label}</button>
        ))}
      </div>

      {/* ── OVERVIEW TAB ── */}
      {tab==="overview" && (
        <div>
          <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:20 }}>
            <KCard label="Net Profit"       value={`GH₵${netProfit.toLocaleString()}`}       color={netProfit>=0?C.accent:C.red} icon="◎" trend={8}/>
            <KCard label="Total Revenue"    value={`GH₵${totalRevenue.toLocaleString()}`}     color={C.green}  icon="◈" trend={12}/>
            <KCard label="Total Expenses"   value={`GH₵${(totalPurchases+totalExpenses).toLocaleString()}`} color={C.red} icon="◑"/>
            <KCard label="Stock Value"      value={`GH₵${stockValue.toLocaleString()}`}       color={C.blue}   icon="◫"/>
            <KCard label="Unpaid (Customers)" value={`GH₵${unpaidSales.toLocaleString()}`}   color={C.gold}   icon="⏳"/>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr", gap:16, marginBottom:16 }}>
            <SCard title="📈 Revenue · Expenses · Profit (Monthly)">
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={revenueChart}>
                  <defs>
                    <linearGradient id="ag1" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={C.green} stopOpacity={0.3}/><stop offset="95%" stopColor={C.green} stopOpacity={0}/></linearGradient>
                    <linearGradient id="ag2" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={C.red} stopOpacity={0.3}/><stop offset="95%" stopColor={C.red} stopOpacity={0}/></linearGradient>
                    <linearGradient id="ag3" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={C.accent} stopOpacity={0.3}/><stop offset="95%" stopColor={C.accent} stopOpacity={0}/></linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
                  <XAxis dataKey="month" stroke={C.muted} tick={{fill:C.muted,fontSize:10}}/>
                  <YAxis stroke={C.muted} tick={{fill:C.muted,fontSize:10}} tickFormatter={v=>`₵${v}`}/>
                  <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text}} formatter={v=>[`GH₵${v}`]}/>
                  <Legend wrapperStyle={{color:C.muted,fontSize:11}}/>
                  <Area type="monotone" dataKey="revenue"  stroke={C.green}  fill="url(#ag1)" strokeWidth={2} name="Revenue"/>
                  <Area type="monotone" dataKey="expenses" stroke={C.red}    fill="url(#ag2)" strokeWidth={2} name="Expenses"/>
                  <Area type="monotone" dataKey="profit"   stroke={C.accent} fill="url(#ag3)" strokeWidth={2} name="Net Profit"/>
                </AreaChart>
              </ResponsiveContainer>
            </SCard>

            <SCard title="⚡ System At a Glance">
              {[
                ["Inventory Items",     data.inventory.length,  C.blue],
                ["Low Stock Alerts",    lowStockCount,          lowStockCount>0?C.red:C.green],
                ["Total Customers",     data.customers.length,  C.purple],
                ["Total Suppliers",     data.suppliers.length,  C.accent],
                ["Active Staff",        activeStaff,            C.green],
                ["Monthly Payroll",     `GH₵${payroll.toLocaleString()}`, C.orange],
                ["Pending Deliveries",  pendingDels,            pendingDels>0?C.gold:C.green],
                ["Total Sales",         data.sales.length,      C.green],
                ["Total Purchases",     data.purchases.length,  C.blue],
                ["Audit Log Entries",   auditLog.length,        C.muted],
              ].map(([l,v,col])=>(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"6px 0", borderBottom:`1px solid ${C.border}18` }}>
                  <span style={{ color:C.muted, fontSize:12 }}>{l}</span>
                  <span style={{ color:col, fontWeight:700, fontSize:13 }}>{v}</span>
                </div>
              ))}
            </SCard>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:16 }}>
            <SCard title="💰 Debt Summary">
              {[["Customers Owe You",`GH₵${totalCustDebt.toLocaleString()}`,C.green],["You Owe Suppliers",`GH₵${totalSupDebt.toLocaleString()}`,C.red],["Net",`GH₵${(totalCustDebt-totalSupDebt).toLocaleString()}`,totalCustDebt>=totalSupDebt?C.accent:C.red]].map(([l,v,col])=>(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid ${C.border}18` }}>
                  <span style={{ color:C.muted, fontSize:12 }}>{l}</span><span style={{ color:col, fontWeight:800, fontSize:14 }}>{v}</span>
                </div>
              ))}
            </SCard>
            <SCard title="🧾 Invoice Status">
              {[["Paid Invoices", data.sales.filter(s=>s.status==="paid").length, C.green],["Unpaid Invoices", data.sales.filter(s=>s.status==="unpaid").length, C.gold],["Paid Purchases", data.purchases.filter(p=>p.status==="paid").length, C.green],["Unpaid Purchases", data.purchases.filter(p=>p.status==="unpaid").length, C.red]].map(([l,v,col])=>(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid ${C.border}18` }}>
                  <span style={{ color:C.muted, fontSize:12 }}>{l}</span><span style={{ color:col, fontWeight:800, fontSize:14 }}>{v}</span>
                </div>
              ))}
            </SCard>
            <SCard title="📦 Inventory Health">
              {data.inventory.slice(0,5).map(i=>(
                <div key={i.id} style={{ marginBottom:9 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", marginBottom:3 }}>
                    <span style={{ color:C.text, fontSize:11 }}>{i.name.split(" ")[0]}</span>
                    <span style={{ color:i.qty<=i.reorder?C.red:C.green, fontSize:11, fontWeight:700 }}>{i.qty}/{i.reorder}</span>
                  </div>
                  <div style={{ background:C.dim, borderRadius:3, height:4 }}>
                    <div style={{ background:i.qty<=i.reorder?C.red:C.accent, borderRadius:3, height:4, width:`${Math.min(100,i.qty/Math.max(i.reorder*2,1)*100)}%` }}/>
                  </div>
                </div>
              ))}
            </SCard>
          </div>
        </div>
      )}

      {/* ── FINANCIALS TAB ── */}
      {tab==="financial" && (
        <div>
          <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:20 }}>
            <KCard label="Gross Profit"    value={`GH₵${(totalRevenue-totalPurchases).toLocaleString()}`} color={C.green} icon="◈"/>
            <KCard label="Net Profit"      value={`GH₵${netProfit.toLocaleString()}`}                     color={netProfit>=0?C.accent:C.red} icon="◎"/>
            <KCard label="Total Revenue"   value={`GH₵${totalRevenue.toLocaleString()}`}                  color={C.green} icon="⬆"/>
            <KCard label="Total Expenses"  value={`GH₵${totalExpenses.toLocaleString()}`}                 color={C.orange} icon="◑"/>
            <KCard label="Cost of Goods"   value={`GH₵${totalPurchases.toLocaleString()}`}                color={C.red}  icon="⬇"/>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
            <SCard title="📊 Monthly Profit Bar">
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={revenueChart}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
                  <XAxis dataKey="month" stroke={C.muted} tick={{fill:C.muted,fontSize:10}}/>
                  <YAxis stroke={C.muted} tick={{fill:C.muted,fontSize:10}} tickFormatter={v=>`₵${v}`}/>
                  <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,color:C.text}} formatter={v=>[`GH₵${v}`]}/>
                  <Legend wrapperStyle={{color:C.muted,fontSize:10}}/>
                  <Bar dataKey="revenue"  fill={C.green}  name="Revenue"  radius={[3,3,0,0]}/>
                  <Bar dataKey="expenses" fill={C.red}    name="Expenses" radius={[3,3,0,0]}/>
                  <Bar dataKey="profit"   fill={C.accent} name="Profit"   radius={[3,3,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </SCard>
            <SCard title="🧮 Full P&L Breakdown">
              {[
                ["Revenue (Paid)",       `GH₵${data.sales.filter(s=>s.status==="paid").reduce((a,s)=>a+s.total,0).toLocaleString()}`,  C.green],
                ["Revenue (Unpaid)",     `GH₵${unpaidSales.toLocaleString()}`,       C.gold],
                ["Total Revenue",        `GH₵${totalRevenue.toLocaleString()}`,       C.green],
                ["—","",""],
                ["Cost of Goods",        `GH₵${totalPurchases.toLocaleString()}`,     C.red],
                ["Gross Profit",         `GH₵${(totalRevenue-totalPurchases).toLocaleString()}`, (totalRevenue-totalPurchases)>=0?C.blue:C.red],
                ["—","",""],
                ["Operating Expenses",   `GH₵${totalExpenses.toLocaleString()}`,      C.red],
                ["Monthly Payroll",      `GH₵${payroll.toLocaleString()}`,            C.orange],
                ["—","",""],
                ["Net Profit",           `GH₵${netProfit.toLocaleString()}`,          netProfit>=0?C.accent:C.red],
              ].map(([l,v,col],i)=>l==="—"?<div key={i} style={{borderBottom:`1px solid ${C.border}`,margin:"4px 0"}}/>:(
                <div key={l} style={{ display:"flex", justifyContent:"space-between", padding:"6px 0", borderBottom:`1px solid ${C.border}14` }}>
                  <span style={{ color:C.muted, fontSize:12 }}>{l}</span>
                  <span style={{ color:col, fontWeight:700, fontSize:12 }}>{v}</span>
                </div>
              ))}
            </SCard>
          </div>
        </div>
      )}

      {/* ── OPERATIONS TAB ── */}
      {tab==="operations" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
            <SCard title="👥 Staff Overview">
              <DTable headers={["Name","Role","Salary","Status"]}
                rows={data.staff.map(s=>[
                  <span style={{color:C.text,fontWeight:600,fontSize:12}}>{s.name}</span>,
                  <Badge label={s.role} color={C.blue}/>,
                  <span style={{color:C.orange,fontSize:12}}>GH₵{s.salary||"—"}</span>,
                  <Badge label={s.status} color={s.status==="active"?C.green:C.muted}/>
                ])}
              />
              <div style={{ marginTop:12, padding:"10px 0", borderTop:`1px solid ${C.border}` }}>
                <span style={{ color:C.muted, fontSize:12 }}>Total Monthly Payroll: </span>
                <span style={{ color:C.orange, fontWeight:800 }}>GH₵{payroll.toLocaleString()}</span>
              </div>
            </SCard>

            <SCard title="🚚 Delivery Status">
              <DTable headers={["ID","Customer","Driver","Status"]}
                rows={(data.deliveries||[]).map(d=>[
                  <span style={{color:C.cyan,fontWeight:700,fontSize:12}}>#{d.id}</span>,
                  d.customer, d.driver,
                  <Badge label={d.status} color={d.status==="delivered"?C.green:d.status==="in-transit"?C.blue:C.gold}/>
                ])}
              />
            </SCard>
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
            <SCard title="📦 Full Inventory Table">
              <DTable headers={["Item","Qty","Value","Status"]}
                rows={data.inventory.map(i=>[
                  <span style={{color:C.text,fontWeight:600,fontSize:12}}>{i.name}</span>,
                  i.qty,
                  <span style={{color:C.blue,fontSize:12}}>GH₵{(i.qty*i.cost).toLocaleString()}</span>,
                  <Badge label={i.qty<=i.reorder?"Low":"OK"} color={i.qty<=i.reorder?C.red:C.green}/>
                ])}
              />
            </SCard>

            <SCard title="🏆 Top Customers by Revenue">
              {[...data.customers].sort((a,b)=>(b.totalBought||0)-(a.totalBought||0)).map((c,i)=>(
                <div key={c.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"8px 0", borderBottom:`1px solid ${C.border}18` }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    <div style={{ width:22, height:22, borderRadius:"50%", background:[C.gold,C.muted,C.dim][i]||C.dim, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:800, color:C.bg }}>{i+1}</div>
                    <div>
                      <div style={{ color:C.text, fontSize:12, fontWeight:600 }}>{c.name}</div>
                      <div style={{ color:C.muted, fontSize:10 }}>{c.address}</div>
                    </div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ color:C.accent, fontWeight:700, fontSize:13 }}>GH₵{(c.totalBought||0).toLocaleString()}</div>
                    {c.balance>0&&<Badge label={`owes GH₵${c.balance}`} color={C.red}/>}
                  </div>
                </div>
              ))}
            </SCard>
          </div>
        </div>
      )}

      {/* ── SUBSCRIBERS TAB ── */}
      {tab==="subscribers" && (
        <div>
          <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:20 }}>
            <KCard label="Active Subscribers" value={subscribers.length}                                              color={C.accent} icon="◎"/>
            <KCard label="Monthly MoMo Revenue" value={`GH₵${subscribers.reduce((a,s)=>a+(PLANS.find(p=>p.id===s.plan)?.price||0),0).toLocaleString()}`} color={C.green} icon="💳"/>
            <KCard label="Enterprise Plans"   value={subscribers.filter(s=>s.plan==="enterprise").length}            color={C.purple} icon="⬡"/>
            <KCard label="Pro Plans"          value={subscribers.filter(s=>s.plan==="pro").length}                   color={C.gold}   icon="◈"/>
          </div>

          <SCard title="📋 All Subscribers">
            {subscribers.length===0
              ? <div style={{ padding:"24px 0", textAlign:"center" }}>
                  <p style={{ color:C.muted, fontSize:13 }}>No other subscribers yet. Share Makin BizSystem to grow your customer base!</p>
                  <div style={{ marginTop:16, background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:16, display:"inline-block" }}>
                    <p style={{ color:C.accent, fontWeight:700, fontSize:14 }}>Your MoMo: {OWNER_MOMO.number}</p>
                    <p style={{ color:C.muted, fontSize:12, marginTop:4 }}>Clients pay here to activate their subscription</p>
                  </div>
                </div>
              : <DTable
                  headers={["Business","Plan","Phone","Ref #","Activated","Expires","Status"]}
                  rows={subscribers.map(s=>{
                    const plan=PLANS.find(p=>p.id===s.plan);
                    const expired=new Date(s.expiresAt)<new Date();
                    return [
                      <span style={{color:C.text,fontWeight:600,fontSize:12}}>{s.bizName}</span>,
                      <Badge label={s.plan.toUpperCase()} color={plan?.color||C.muted}/>,
                      s.phone, s.ref,
                      new Date(s.activatedAt).toLocaleDateString(),
                      new Date(s.expiresAt).toLocaleDateString(),
                      <Badge label={expired?"Expired":"Active"} color={expired?C.red:C.green}/>
                    ];
                  })}
                />
            }
          </SCard>

          <div style={{ marginTop:16, background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:22 }}>
            <h3 style={{ color:C.text, fontFamily:"'Playfair Display',serif", fontSize:16, marginBottom:14 }}>💡 Pricing Summary</h3>
            <div style={{ display:"flex", gap:14, flexWrap:"wrap" }}>
              {PLANS.map(plan=>(
                <div key={plan.id} style={{ flex:1, minWidth:150, background:C.surface, border:`1px solid ${plan.color}44`, borderRadius:12, padding:16, textAlign:"center" }}>
                  <div style={{ color:plan.color, fontWeight:800, fontSize:16, marginBottom:4 }}>{plan.name}</div>
                  <div style={{ color:C.text, fontSize:24, fontWeight:800 }}>GH₵{plan.price}</div>
                  <div style={{ color:C.muted, fontSize:11 }}>per month</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── USERS & ROLES TAB ── */}
      {tab==="users" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
            <div>
              <h3 style={{ color:C.text, fontFamily:"'Playfair Display',serif", fontSize:20, margin:0 }}>User Accounts & Role Management</h3>
              <p style={{ color:C.muted, fontSize:12, marginTop:4 }}>{users.length} registered accounts · Assign roles to control access</p>
            </div>
          </div>

          {/* Role legend */}
          <div style={{ display:"flex", gap:10, flexWrap:"wrap", marginBottom:20 }}>
            {ROLES.map(r=>(
              <div key={r.id} style={{ background:C.surface, border:`1px solid ${r.color}33`, borderRadius:10, padding:"10px 16px", display:"flex", gap:10, alignItems:"flex-start" }}>
                <div style={{ width:10, height:10, borderRadius:"50%", background:r.color, marginTop:3, flexShrink:0 }}/>
                <div>
                  <div style={{ color:r.color, fontWeight:700, fontSize:12 }}>{r.label}</div>
                  <div style={{ color:C.muted, fontSize:10, marginTop:2 }}>{r.desc}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Users table */}
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, overflow:"hidden" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr>{["Business","Email","Phone","Current Role","Plan","Expires","Actions"].map(h=>(
                  <th key={h} style={{ textAlign:"left", padding:"10px 14px", color:C.muted, fontSize:10, textTransform:"uppercase", letterSpacing:1, borderBottom:`1px solid ${C.border}` }}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {users.map((u,i)=>(
                  <UserRoleRow key={u.id} user={u} currentUser={currentUser}
                    onChangeRole={(newRole)=>{
                      if(u.isOwner){ alert("The system owner role cannot be changed."); return; }
                      if(u.id===currentUser.id){ alert("You cannot change your own role here."); return; }
                      setUsers(prev=>prev.map(x=>x.id===u.id?{...x,role:newRole}:x));
                    }}
                    rowBg={i%2===0?"transparent":C.surface+"44"}
                  />
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop:16, background:C.gold+"10", border:`1px solid ${C.gold}22`, borderRadius:12, padding:16 }}>
            <p style={{ color:C.gold, fontSize:12 }}>⚠ <strong>Role change takes effect on next login.</strong> The owner account role is locked and cannot be changed by anyone.</p>
          </div>
        </div>
      )}

      {/* ── SYSTEM HEALTH TAB ── */}
      {tab==="system" && (
        <div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
            <SCard title="🖥️ System Information">
              {[
                ["System Name",    SYSTEM_NAME],
                ["Version",        `v${SYSTEM_VERSION}`],
                ["MoMo Number",    OWNER_MOMO.number],
                ["Network",        OWNER_MOMO.network],
                ["Account Name",   OWNER_MOMO.name],
                ["Session Started",new Date().toLocaleString()],
                ["Subscription Plan", subscription?.plan?.toUpperCase()||"—"],
                ["Expires",        subscription ? new Date(subscription.expiresAt).toLocaleDateString() : "—"],
                ["Audit Entries",  auditLog.length.toString()],
                ["Total Records",  (data.inventory.length+data.sales.length+data.purchases.length+data.customers.length+data.suppliers.length+data.staff.length).toString()],
              ].map(([k,v])=>(
                <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${C.border}18` }}>
                  <span style={{ color:C.muted, fontSize:12 }}>{k}</span>
                  <span style={{ color:k==="MoMo Number"||k==="Version"?C.accent:C.text, fontWeight:k==="Version"||k==="MoMo Number"?700:400, fontSize:12 }}>{v}</span>
                </div>
              ))}
            </SCard>

            <SCard title="✅ Data Integrity Check">
              {[
                ["Inventory records",   data.inventory.length > 0,      `${data.inventory.length} items`],
                ["Customers with contact", data.customers.every(c=>c.phone), "All have phones"],
                ["Staff with salary",   data.staff.every(s=>s.salary>0),"All have salaries"],
                ["Unpaid invoices",     data.sales.some(s=>s.status==="unpaid"), `${data.sales.filter(s=>s.status==="unpaid").length} pending`, true],
                ["Unpaid purchases",    data.purchases.some(p=>p.status==="unpaid"), `${data.purchases.filter(p=>p.status==="unpaid").length} pending`, true],
                ["Low stock items",     lowStockCount > 0,              `${lowStockCount} items low`, true],
                ["Audit trail active",  auditLog.length > 0,            `${auditLog.length} entries`],
              ].map(([label, condition, detail, isWarning])=>(
                <div key={label} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"8px 0", borderBottom:`1px solid ${C.border}18` }}>
                  <span style={{ color:C.text, fontSize:12 }}>{label}</span>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <span style={{ color:C.muted, fontSize:11 }}>{detail}</span>
                    <Badge label={isWarning&&condition?"⚠ Warn":"✓ OK"} color={isWarning&&condition?C.gold:C.green}/>
                  </div>
                </div>
              ))}
            </SCard>
          </div>

          <SCard title="🔑 Admin Actions">
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
              {[
                {label:"Export Excel Workbook", color:C.blue,  onClick:()=>exportFullWorkbook(data), desc:"All modules as .xls spreadsheet"},
                {label:"Export JSON Backup",    color:C.cyan,  onClick:()=>exportData(data),         desc:"Full JSON backup for restore"},
                {label:"Export P&L PDF",        color:C.green, onClick:()=>exportReportsPDF(data),   desc:"Financial summary ready to print"},
                {label:"Clear Audit Log",    color:C.red,  onClick:()=>alert("Audit log clear requires owner confirmation."), desc:"Permanently remove audit history"},
                {label:"View All Logs",      color:C.accent, onClick:()=>setTab("overview"), desc:"Review system activity"},
              ].map(a=>(
                <div key={a.label} style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:16 }}>
                  <p style={{ color:C.muted, fontSize:11, marginBottom:10 }}>{a.desc}</p>
                  <Btn color={a.color} onClick={a.onClick} small>{a.label}</Btn>
                </div>
              ))}
            </div>
          </SCard>
        </div>
      )}
    </div>
  );
}


/* ══════════════════════════════════════════════════════════════════
   AUDIT TRAIL
══════════════════════════════════════════════════════════════════ */
function AuditTrailPage({ auditLog, clearLog }) {
  const [filter, setFilter]   = useState("all");
  const [search, setSearch]   = useState("");
  const [showClear, setShowClear] = useState(false);

  const ACTION_COLORS = {
    CREATE:  C.green,
    UPDATE:  C.blue,
    DELETE:  C.red,
    LOGIN:   C.accent,
    PAYMENT: C.gold,
    EXPORT:  C.cyan,
    IMPORT:  C.purple,
    VIEW:    C.muted,
    SYSTEM:  C.orange,
  };

  const MODULE_ICONS = {
    Inventory:"◫", Sales:"◈", Purchases:"◉", Customers:"◎",
    Suppliers:"◐", Expenses:"◑", Staff:"◒", Deliveries:"🚚",
    "Price List":"🏷", Debts:"💰", Reports:"◓", Settings:"◧",
    Security:"◨", Admin:"🛡️", System:"⚙",
  };

  const filtered = auditLog.filter(entry=>{
    const matchFilter = filter==="all" || entry.action===filter;
    const matchSearch = search==="" || entry.description.toLowerCase().includes(search.toLowerCase()) || entry.module.toLowerCase().includes(search.toLowerCase()) || entry.user.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const actionCounts = auditLog.reduce((acc,e)=>{ acc[e.action]=(acc[e.action]||0)+1; return acc; },{});
  const moduleCounts = auditLog.reduce((acc,e)=>{ acc[e.module]=(acc[e.module]||0)+1; return acc; },{});

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:22 }}>
        <div>
          <h2 style={{ color:C.text, fontFamily:"'Playfair Display',serif", fontSize:26, margin:0 }}>Audit Trail</h2>
          <p style={{ color:C.muted, fontSize:12, marginTop:4 }}>{auditLog.length} total entries · Full system activity log</p>
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <ExportMenu options={[
          {icon:"📊",label:"Export Excel", desc:"Structured audit log spreadsheet", action:()=>exportAuditExcel(auditLog)},
          {icon:"📄",label:"Export PDF",   desc:"Printable audit trail report",     action:()=>exportAuditPDF(auditLog)},
          {icon:"💾",label:"Export JSON",  desc:"Raw log data backup",              action:()=>{ const blob=new Blob([JSON.stringify(auditLog,null,2)],{type:"application/json"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=`audit-log-${new Date().toISOString().slice(0,10)}.json`; a.click(); }},
        ]}/>
          <Btn small outline color={C.red}   onClick={()=>setShowClear(true)}>🗑 Clear Log</Btn>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginBottom:20 }}>
        {Object.entries(actionCounts).map(([action,count])=>(
          <div key={action} style={{ background:C.card, border:`1px solid ${ACTION_COLORS[action]||C.border}33`, borderRadius:10, padding:"12px 18px", display:"flex", flexDirection:"column", alignItems:"center" }}>
            <span style={{ color:ACTION_COLORS[action]||C.muted, fontWeight:800, fontSize:18 }}>{count}</span>
            <span style={{ color:C.muted, fontSize:10, textTransform:"uppercase", letterSpacing:1 }}>{action}</span>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display:"flex", gap:10, marginBottom:18, alignItems:"center", flexWrap:"wrap" }}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search logs..." style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:8, padding:"7px 12px", color:C.text, fontSize:12, outline:"none", flex:1, minWidth:200 }}/>
        {["all","CREATE","UPDATE","DELETE","LOGIN","PAYMENT","EXPORT","IMPORT","SYSTEM"].map(f=>(
          <button key={f} onClick={()=>setFilter(f)} style={{ background:filter===f?(ACTION_COLORS[f]||C.accent):"none", color:filter===f?C.bg:C.muted, border:`1px solid ${filter===f?(ACTION_COLORS[f]||C.accent):C.border}`, borderRadius:7, padding:"5px 12px", cursor:"pointer", fontSize:11, fontWeight:700, fontFamily:"'Barlow Condensed',sans-serif", letterSpacing:0.5 }}>
            {f==="all"?"ALL":f}
          </button>
        ))}
      </div>

      {/* Log Table */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, overflow:"hidden", marginBottom:16 }}>
        {filtered.length===0
          ? <div style={{ padding:32, textAlign:"center", color:C.muted, fontSize:13 }}>No audit entries found matching your filters.</div>
          : (
            <div style={{ overflowX:"auto" }}>
              <table style={{ width:"100%", borderCollapse:"collapse" }}>
                <thead>
                  <tr>
                    {["#","Time","Action","Module","Description","User","IP / Session"].map(h=>(
                      <th key={h} style={{ textAlign:"left", padding:"9px 12px", color:C.muted, fontSize:10, textTransform:"uppercase", letterSpacing:1, borderBottom:`1px solid ${C.border}`, whiteSpace:"nowrap" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[...filtered].reverse().map((entry,i)=>(
                    <tr key={entry.id} style={{ borderBottom:`1px solid ${C.border}15`, background:i%2===0?"transparent":C.surface+"44" }}>
                      <td style={{ padding:"9px 12px", color:C.muted, fontSize:11 }}>#{entry.id}</td>
                      <td style={{ padding:"9px 12px", color:C.muted, fontSize:11, whiteSpace:"nowrap" }}>{entry.timestamp}</td>
                      <td style={{ padding:"9px 12px" }}><Badge label={entry.action} color={ACTION_COLORS[entry.action]||C.muted}/></td>
                      <td style={{ padding:"9px 12px" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                          <span style={{ fontSize:13 }}>{MODULE_ICONS[entry.module]||"◦"}</span>
                          <span style={{ color:C.text, fontSize:12 }}>{entry.module}</span>
                        </div>
                      </td>
                      <td style={{ padding:"9px 12px", color:C.text, fontSize:12, maxWidth:300 }}>{entry.description}</td>
                      <td style={{ padding:"9px 12px", color:C.accent, fontSize:12, fontWeight:600 }}>{entry.user}</td>
                      <td style={{ padding:"9px 12px", color:C.muted, fontSize:11 }}>{entry.session}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        }
      </div>

      {/* Module Activity */}
      <SCard title="📊 Activity by Module">
        <div style={{ display:"flex", flexWrap:"wrap", gap:10 }}>
          {Object.entries(moduleCounts).sort((a,b)=>b[1]-a[1]).map(([mod,count])=>(
            <div key={mod} style={{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:9, padding:"8px 14px", display:"flex", gap:8, alignItems:"center" }}>
              <span style={{ fontSize:13 }}>{MODULE_ICONS[mod]||"◦"}</span>
              <span style={{ color:C.text, fontSize:12 }}>{mod}</span>
              <span style={{ color:C.accent, fontWeight:800, fontSize:14 }}>{count}</span>
            </div>
          ))}
        </div>
      </SCard>

      {/* Clear confirm modal */}
      {showClear && (
        <Modal title="Clear Audit Log" onClose={()=>setShowClear(false)}>
          <div style={{ background:C.red+"14", border:`1px solid ${C.red}33`, borderRadius:10, padding:14, marginBottom:18 }}>
            <p style={{ color:C.red, fontSize:13, fontWeight:600 }}>⚠ This action cannot be undone.</p>
            <p style={{ color:C.muted, fontSize:12, marginTop:6 }}>All {auditLog.length} audit log entries will be permanently deleted. Export the log first if you need to keep a record.</p>
          </div>
          <div style={{ display:"flex", gap:10, justifyContent:"flex-end" }}>
            <Btn outline color={C.muted} onClick={()=>setShowClear(false)}>Cancel</Btn>
            <Btn color={C.red} onClick={()=>{ clearLog(); setShowClear(false); }}>Yes, Clear All Logs</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}
