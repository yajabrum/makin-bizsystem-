# Makin BizSystem v2.0

Professional Business Management System for Provisions Companies.

---

## 🔐 Owner Login
- **Email:** admin@makinlimited.com  
- **Password:** Makin@2024

---

## 🚀 Deploy in 5 Minutes (Free)

### Option A — Vercel (Recommended)

1. Go to https://github.com and create a free account
2. Create a new repository called `makin-bizsystem`
3. Upload all files from this folder into the repository
4. Go to https://vercel.com and sign in with GitHub
5. Click **"Add New Project"** → select your `makin-bizsystem` repo
6. Click **Deploy** — Vercel auto-detects Create React App
7. Your live URL will be: `https://makin-bizsystem.vercel.app`

### Option B — Netlify Drop (No GitHub needed)

1. Run `npm install` then `npm run build` in this folder
2. Go to https://app.netlify.com/drop
3. Drag and drop the `build/` folder onto the page
4. Get your instant live URL

### Option C — Run Locally

```bash
npm install
npm start
```
Opens at http://localhost:3000

---

## 📦 Dependencies
- react + react-dom
- react-scripts (Create React App)
- recharts (charts)
- xlsx (Excel export)

---

## 📞 Support
MoMo: 0596363851 | Makin Limited
